@echo off
chcp 65001 >nul
cd /d "%~dp0"
py usb_rs485_air_sensor.py
echo.
pause

