@echo off
chcp 65001 >nul
echo กำลังติดตั้งไลบรารี pyserial...
py -m pip install pyserial
echo.
echo ติดตั้งเสร็จแล้ว กดปุ่มใดก็ได้เพื่อปิด
pause >nul

