/*
  ============================================================================
  บทเรียน: ESP32-S3 อ่านเซนเซอร์ดิน 7-in-1 ผ่าน RS485 Modbus
  แล้วแสดงค่าบน Serial Monitor ของ Arduino IDE
  ============================================================================

  อุปกรณ์ที่ใช้
  - ESP32-S3
  - โมดูลแปลงสัญญาณ RS485 ที่รองรับลอจิก 3.3V
  - เซนเซอร์ดิน 7-in-1 แบบ Modbus RTU

  การต่อสายตามชุด Smart Farm นี้
  ESP32 GPIO17 (TX) -> ขารับข้อมูลของโมดูล RS485
  ESP32 GPIO18 (RX) <- ขาส่งข้อมูลของโมดูล RS485
  ESP32 GND         -> GND ของโมดูล RS485
  RS485 A           -> A ของเซนเซอร์
  RS485 B           -> B ของเซนเซอร์

  ก่อนอัปโหลดให้ตรวจ 4 ค่าในหัวข้อ "ค่าที่นักเรียนแก้ได้" ด้านล่าง
  ============================================================================
*/

#include <Arduino.h>       // คำสั่งพื้นฐานของ Arduino และ Serial Monitor
#include <ModbusMaster.h>  // ไลบรารีสำหรับอ่านอุปกรณ์ Modbus RTU

// ============================================================================
// ค่าที่นักเรียนแก้ได้ก่อนอัปโหลด
// ============================================================================

const uint8_t RS485_TX_PIN = 17;       // ขา TX ของ ESP32
const uint8_t RS485_RX_PIN = 18;       // ขา RX ของ ESP32
const uint32_t MODBUS_BAUD = 9600;     // ความเร็ว ต้องตรงกับเซนเซอร์
const uint8_t SENSOR_ID = 2;           // Modbus Slave ID ของเซนเซอร์

// เซนเซอร์รุ่นนี้เริ่มข้อมูลที่ Register 0 และอ่านต่อเนื่องทั้งหมด 8 ช่อง
const uint16_t START_REGISTER = 0x0000;
const uint8_t REGISTER_COUNT = 8;

// อ่านใหม่ทุก 2 วินาที เพื่อให้ข้อความบนหน้าจอไม่ไหลเร็วเกินไป
const unsigned long READ_INTERVAL_MS = 2000;

// ใช้ UART2 ของ ESP32 สำหรับติดต่อ RS485
HardwareSerial rs485Serial(2);

// ตัวแปร sensor ทำหน้าที่เป็น Modbus Master สำหรับส่งคำถามไปยังเซนเซอร์
ModbusMaster sensor;

// เก็บเวลาที่อ่านเซนเซอร์ครั้งล่าสุด
unsigned long lastReadTime = 0;

// แปลงเลข 16 บิตให้เป็นเลขติดลบได้ ใช้กับค่าอุณหภูมิ
float signedValueDividedBy10(uint16_t rawValue) {
  int16_t signedValue = static_cast<int16_t>(rawValue);
  return signedValue / 10.0f;
}

// แสดงเส้นแบ่งเพื่อให้อ่านข้อมูลแต่ละรอบง่ายขึ้น
void printLine() {
  Serial.println(F("--------------------------------------------------"));
}

// อธิบายรหัสข้อผิดพลาดที่พบบ่อยให้เด็กเข้าใจง่าย
void printModbusError(uint8_t errorCode) {
  Serial.print(F("อ่านไม่สำเร็จ รหัสข้อผิดพลาด = 0x"));
  if (errorCode < 0x10) Serial.print('0');
  Serial.println(errorCode, HEX);

  switch (errorCode) {
    case 0xE0:
      Serial.println(F("คำแนะนำ: เซนเซอร์ตอบข้อมูลไม่ถูกต้อง"));
      break;
    case 0xE1:
      Serial.println(F("คำแนะนำ: เซนเซอร์อาจใช้ Function Code ไม่ตรงกัน"));
      break;
    case 0xE2:
      Serial.println(F("คำแนะนำ: ตรวจสาย A/B, ไฟเลี้ยง, Baud rate และ Sensor ID"));
      break;
    case 0xE3:
      Serial.println(F("คำแนะนำ: ตรวจสัญญาณรบกวนและสาย RS485"));
      break;
    default:
      Serial.println(F("คำแนะนำ: ตรวจการต่อสายและค่าตั้งของเซนเซอร์"));
      break;
  }
}

// อ่าน Register 0-7 แล้วแปลงเป็นหน่วยที่อ่านเข้าใจง่าย
void readAndPrintSensor() {
  printLine();
  Serial.print(F("กำลังอ่านเซนเซอร์ Modbus ID = "));
  Serial.println(SENSOR_ID);

  // Function Code 03: อ่าน Holding Registers จำนวน 8 ช่อง
  uint8_t result = sensor.readHoldingRegisters(START_REGISTER, REGISTER_COUNT);

  // ku8MBSuccess หมายถึงเซนเซอร์ตอบกลับถูกต้อง
  if (result != sensor.ku8MBSuccess) {
    printModbusError(result);
    return;
  }

  // getResponseBuffer(ตำแหน่ง) ใช้อ่านข้อมูลแต่ละ Register ที่ตอบกลับมา
  uint16_t rawMoisture = sensor.getResponseBuffer(0);
  uint16_t rawTemperature = sensor.getResponseBuffer(1);
  uint16_t rawEc = sensor.getResponseBuffer(2);
  uint16_t rawPh = sensor.getResponseBuffer(3);
  uint16_t rawNitrogen = sensor.getResponseBuffer(4);
  uint16_t rawPhosphorus = sensor.getResponseBuffer(5);
  uint16_t rawPotassium = sensor.getResponseBuffer(6);
  uint16_t rawSalinity = sensor.getResponseBuffer(7);

  // เซนเซอร์ส่งความชื้น อุณหภูมิ และ pH มาเป็นค่า x10 จึงต้องหารด้วย 10
  float moisture = rawMoisture / 10.0f;
  float temperature = signedValueDividedBy10(rawTemperature);
  float ph = rawPh / 10.0f;

  Serial.println(F("อ่านสำเร็จ ได้ค่าดังนี้"));

  Serial.print(F("1. ความชื้นดิน  = "));
  Serial.print(moisture, 1);
  Serial.println(F(" %"));

  Serial.print(F("2. อุณหภูมิดิน = "));
  Serial.print(temperature, 1);
  Serial.println(F(" °C"));

  Serial.print(F("3. EC           = "));
  Serial.print(rawEc);
  Serial.println(F(" us/cm"));

  Serial.print(F("4. pH           = "));
  Serial.println(ph, 1);

  Serial.print(F("5. Nitrogen (N) = "));
  Serial.print(rawNitrogen);
  Serial.println(F(" mg/kg"));

  Serial.print(F("6. Phosphorus(P)= "));
  Serial.print(rawPhosphorus);
  Serial.println(F(" mg/kg"));

  Serial.print(F("7. Potassium (K)= "));
  Serial.print(rawPotassium);
  Serial.println(F(" mg/kg"));

  Serial.print(F("8. ความเค็ม SAL = "));
  Serial.print(rawSalinity);
  Serial.println(F(" mg/L"));
}

// setup() ทำงานเพียงครั้งเดียวเมื่อเปิดเครื่องหรือกด Reset
void setup() {
  // เปิด Serial Monitor ที่ความเร็ว 115200 baud
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  printLine();
  Serial.println(F("บทเรียนอ่านเซนเซอร์ดินผ่าน RS485 Modbus"));
  Serial.println(F("เปิด Serial Monitor ที่ 115200 baud"));
  printLine();

  // เปิด UART2 ตามความเร็วและขาที่กำหนดไว้ด้านบน
  // SERIAL_8N1 หมายถึง Data 8 bit, ไม่มี Parity และ Stop bit 1 bit
  rs485Serial.begin(MODBUS_BAUD, SERIAL_8N1, RS485_RX_PIN, RS485_TX_PIN);

  // กำหนดว่าเราจะคุยกับเซนเซอร์ Slave ID ใด ผ่านพอร์ตใด
  sensor.begin(SENSOR_ID, rs485Serial);

  Serial.println(F("เริ่มระบบเรียบร้อย กำลังอ่านค่า..."));

  // อ่านทันทีหนึ่งครั้งหลังเปิดเครื่อง
  readAndPrintSensor();
  lastReadTime = millis();
}

// loop() ทำงานวนซ้ำตลอดเวลาขณะที่ ESP32 เปิดอยู่
void loop() {
  unsigned long currentTime = millis();

  // ถ้าครบ 2 วินาที ให้เรียกฟังก์ชันอ่านเซนเซอร์อีกครั้ง
  if (currentTime - lastReadTime >= READ_INTERVAL_MS) {
    lastReadTime = currentTime;
    readAndPrintSensor();
  }
}

