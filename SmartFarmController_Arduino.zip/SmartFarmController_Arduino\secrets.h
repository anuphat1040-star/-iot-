#pragma once

// ============================================================================
// จุดที่ต้องตรวจและแก้ก่อนอัปโหลด
// ไฟล์นี้มีรหัสผ่านจริง ห้ามส่งต่อหรือเผยแพร่สู่สาธารณะ
// ข้อความในเครื่องหมาย "..." แก้ได้ แต่ต้องเก็บเครื่องหมายคำพูดไว้
// ============================================================================

// ชื่อและรหัสผ่าน Wi-Fi หลักที่ ESP32 จะเชื่อมต่อ
#define WIFI_SSID "Dr_Samart_007"
#define WIFI_PASSWORD "0807999907"

// MQTT_HOST = ที่อยู่เครื่องรับส่งข้อมูลระหว่าง ESP32 กับเว็บ
// MQTT_PORT 1883 = ไม่เข้ารหัส เหมาะสำหรับทดสอบเท่านั้น
#define MQTT_HOST "broker.hivemq.com"
// IP สำรอง หากไม่ใช้ให้เป็นข้อความว่าง ""
#define MQTT_FALLBACK_IP ""
#define MQTT_PORT 1883
// ชื่อผู้ใช้/รหัสผ่าน MQTT; broker ทดสอบปัจจุบันอนุญาตให้เว้นว่าง
#define MQTT_USERNAME ""
#define MQTT_PASSWORD ""
// true อนุญาต public broker; ระบบจริงควรใช้ private broker แบบ TLS
#define MQTT_ALLOW_PUBLIC_BROKER true

// MQTT_BASE_TOPIC = ชื่อกลุ่มข้อมูลหลัก
// สำคัญ: DEVICE_ID ต้องไม่ซ้ำกับตู้ ESP32 เครื่องอื่น
#define MQTT_BASE_TOPIC "smart-farm"
#define DEVICE_ID "FBP-0001"

// ค่า Firebase ของเว็บ ปกติไม่ต้องแก้สำหรับการอัปโหลด ESP32 ชุดนี้
#define FIREBASE_PROJECT_ID "smart-farm-controller"
#define FIREBASE_API_KEY "AIzaSyD1PMq4EzEV7hUN4z4tUIN1ZcYgzRU3088"
