#pragma once

// Wi-Fi สำรอง/ค่าหน้างาน เฟิร์มแวร์บางโปรไฟล์จะเลือกใช้ค่านี้แทน secrets.h
// ก่อนอัปโหลดควรตรวจให้เป็นเครือข่ายเดียวกับที่ต้องการใช้งานจริง
#define WIFI_OVERRIDE_SSID "Dr_Samart_007"
#define WIFI_OVERRIDE_PASSWORD "0807999907"
