#pragma once

// ==================== RS485 / MODBUS (ตรวจสายก่อนอัปโหลด) ====================
// ขา TX/RX ของ UART2 และความเร็วสื่อสาร อุปกรณ์ทุกตัวต้องใช้ baud rate ตรงกัน
#define RS485_TXD 17
#define RS485_RXD 18
#define MODBUS_BAUDRATE 9600

// ==================== จอสัมผัส HMI ====================
// จอ Kinseal AMT043 ถูกตั้งเป็น Modbus Slave; ESP32 เป็น Master เพียงตัวเดียว
#define HMI_MODBUS_ENABLED true
#define HMI_NODE_ID 5                       // Slave ID ของจอ ต้องไม่ซ้ำอุปกรณ์อื่น
#define HMI_SYNC_INTERVAL_MS 750UL          // ส่งค่าขึ้นจอทุก 750 มิลลิวินาที
#define HMI_OFFLINE_RETRY_MS 10000UL        // จอหลุด ให้ลองใหม่ทุก 10 วินาที
#define HMI_LOCAL_CONTROL_MAX_SECONDS 300UL // สั่งจากจอให้เปิดได้สูงสุด 5 นาที

// ==================== จอ LCD I2C 20x4 ====================
#define LCD_I2C_ENABLED true
#define LCD_I2C_ADDRESS 0x27 // ที่อยู่ I2C ของจอ
#define LCD_SDA_PIN 8        // ขาข้อมูล I2C
#define LCD_SCL_PIN 9        // ขาสัญญาณนาฬิกา I2C
#define LCD_COLUMNS 20
#define LCD_ROWS 4
#define LCD_PAGE_INTERVAL_MS 5000UL       // เปลี่ยนหน้าข้อมูลทุก 5 วินาที
#define LCD_MAPPING_PROBE_ON_BOOT false   // true = ทดลองค้นหาการต่อขา LCD ตอนเปิด

// ==================== รีเลย์ที่ติดอยู่บนบอร์ด ESP32-S3 ====================
// ค่า false + LOCK_OFF true หมายถึงล็อกรีเลย์บนบอร์ดให้ปิดเพื่อความปลอดภัย
// อย่าเปลี่ยนจนกว่าจะยืนยันรุ่นบอร์ดและ GPIO จริง
#define ONBOARD_RELAY_CONTROL_ENABLED false
#define ONBOARD_RELAY_LOCK_OFF true
#define ONBOARD_RELAY_OFF_LEVEL LOW
#define ONBOARD_RELAY_ON_LEVEL HIGH
#define ONBOARD_RELAY_CH1_PIN 1
#define ONBOARD_RELAY_CH2_PIN 2
#define ONBOARD_RELAY_CH3_PIN 41
#define ONBOARD_RELAY_CH4_PIN 42
#define ONBOARD_RELAY_CH5_PIN 45
#define ONBOARD_RELAY_CH6_PIN 46

// ==================== MODBUS SLAVE ID (ต้องตรงกับอุปกรณ์จริง) ====================
#define RELAY_NODE_ID 1       // บอร์ดรีเลย์ภายนอก
#define SENSOR_3IN1_NODE_ID 2 // เซนเซอร์ดิน 7-in-1 ที่ติดตั้งจริง
#define SOIL_4IN1_NODE_ID 3   // อุปกรณ์รุ่นเดิม/สำรอง
#define NPK_NODE_ID 4         // อุปกรณ์ NPK รุ่นเดิม/สำรอง

// ==================== การจับคู่ช่องรีเลย์ภายนอก ====================
// บอร์ด RS485 ปัจจุบันควบคุมเฉพาะวาล์ว 4 โซน ค่า 0 หมายถึงไม่ได้กำหนดช่องปั๊ม
// หากเดินสายคนละช่อง ให้แก้ RELAY_ZONE_1 ถึง RELAY_ZONE_4 ให้ตรงของจริง
#define RELAY_PUMP_WATER 0
#define RELAY_PUMP_FERTILIZER 0
#define RELAY_ZONE_1 1
#define RELAY_ZONE_2 2
#define RELAY_ZONE_3 3
#define RELAY_ZONE_4 4
#define RELAY_MAPPING_VERSION 3

// ==================== Register ของเซนเซอร์ดิน 7-in-1 ====================
// อ่านด้วย Function Code 03 ต่อเนื่อง 8 ช่องจาก address 0x0000
// 0 ความชื้น x10, 1 อุณหภูมิแบบ signed x10, 2 EC, 3 pH x10,
// 4 N, 5 P, 6 K, 7 ความเค็ม (mg/L)
#define SOIL_7IN1_START_REG 0x0000
#define SOIL_7IN1_REGISTER_COUNT 8

// Register รุ่นเดิม เก็บไว้เพื่อให้ค่าตั้งจากระบบเก่ายังใช้งานได้
#define NODE2_HUMI_REG 0x0000
#define NODE2_TEMP_REG 0x0001
#define NODE2_LUX_REG 0x0002

#define NODE3_SOIL_REG 0x0000
#define NODE3_TEMP_REG 0x0001
#define NODE3_EC_REG 0x0002
#define NODE3_PH_REG 0x0003

#define NODE4_N_REG 0x001E
#define NODE4_P_REG 0x001F
#define NODE4_K_REG 0x0020

// ==================== รอบเวลาและระบบความปลอดภัย ====================
#define SENSOR_POLL_INTERVAL_MS 500UL          // อ่านเซนเซอร์ทุก 0.5 วินาที
#define MODBUS_SENSOR_TIMEOUT_MS 200UL         // รอคำตอบเซนเซอร์สูงสุด 0.2 วินาที
#define RELAY_FEEDBACK_POLL_INTERVAL_MS 1000UL // ตรวจสถานะรีเลย์ทุก 1 วินาที
#define WATER_PATH_SETTLE_DELAY_MS 150UL       // รอทางน้ำเข้าที่ก่อนสั่งขั้นต่อไป
// รีเลย์หน้างานนี้รับคำสั่งแต่ไม่ตอบกลับ จึงถือ timeout เป็น “ส่งแล้วแต่ยังไม่ยืนยัน”
#define RELAY_ACCEPT_TIMEOUT_AS_UNCONFIRMED true
#define RELAY_REPLY_WINDOW_MS 180UL           // ช่วงรอคำตอบรีเลย์
#define EMERGENCY_OFF_RETRIES 3               // สั่งปิดฉุกเฉินซ้ำ 3 ครั้ง
#define EMERGENCY_OFF_RETRY_DELAY_MS 40UL     // เว้น 40 ms ระหว่างคำสั่งฉุกเฉิน
#define LOCAL_RELAY_AUTO_OFF_SECONDS 300UL    // สั่งจาก HMI แล้วปิดเองใน 5 นาที
#define TELEMETRY_INTERVAL_MS 5000UL          // ส่งข้อมูลขึ้นเว็บทุก 5 วินาที
#define FLOW_CHECK_DELAY_MS 10000UL           // รอ 10 วินาทีก่อนตรวจอัตราการไหล
#define MIN_SAFE_WATER_LEVEL_PERCENT 25.0f    // น้ำต่ำกว่า 25% ถือว่าไม่ปลอดภัย
#define MIN_FLOW_RATE_LPM 0.2f                // อัตราการไหลต่ำสุด 0.2 ลิตร/นาที

// การเชื่อมต่อ MQTT/Wi-Fi: เวลารอและช่วงลองเชื่อมต่อใหม่
#define MQTT_KEEPALIVE_SECONDS 30
#define MQTT_SOCKET_TIMEOUT_SECONDS 8
#define MQTT_RECONNECT_MIN_MS 2000UL
#define MQTT_RECONNECT_MAX_MS 60000UL
#define WIFI_RECONNECT_MIN_MS 2000UL
#define WIFI_RECONNECT_MAX_MS 60000UL
#define WIFI_CONNECT_TIMEOUT_MS 15000UL
#define MODBUS_DEBUG true                  // true = พิมพ์รายละเอียด Modbus ทาง Serial
#define MODBUS_SCAN_ON_BOOT false          // true = สแกนทุก Slave ตอนเปิด (ปกติไม่ต้องเปิด)
#define RELAY_READ_ONLY_SCAN_ON_BOOT false // true = สแกนรีเลย์แบบอ่านอย่างเดียว

// ปิดการเขียน Firebase REST โดยตรงไว้เพื่อความปลอดภัย
#define FIREBASE_REST_ENABLED false

// ใบรับรอง Root CA สำหรับ MQTT TLS; ระบบจริง port 8883 ต้องใส่ค่า PEM ที่ถูกต้อง
#ifndef MQTT_ROOT_CA
#define MQTT_ROOT_CA ""
#endif
