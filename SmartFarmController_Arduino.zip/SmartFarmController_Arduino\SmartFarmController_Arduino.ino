/*
  ============================================================================
  SMART FARM CONTROLLER สำหรับ ESP32-S3
  ============================================================================

  อ่านก่อนอัปโหลด
  1) เปิดแท็บ README_TH.h เพื่ออ่านคำอธิบายภาษาไทยและรายการที่ต้องแก้
  2) เปิดแท็บ secrets.h แล้วตรวจ Wi-Fi, MQTT และ DEVICE_ID
  3) เปิดแท็บ config.h แล้วตรวจขา RS485, Slave ID และช่องรีเลย์
  4) ใน Arduino IDE เลือก Board = ESP32S3 Dev Module
  5) เลือก USB CDC On Boot = Enabled และ Serial Monitor = 115200 baud
  6) ถอดปั๊ม/วาล์วกำลังสูงออกก่อนทดสอบครั้งแรก

  คอมเมนต์ที่ขึ้นต้นด้วย // เป็นคำอธิบาย โปรแกรมจะไม่ประมวลผลข้อความส่วนนั้น
  #define คือการกำหนดค่าคงที่ และ #include คือการเรียกใช้ไลบรารีหรือไฟล์ตั้งค่า
  ============================================================================
*/

#include <Arduino.h>           // คำสั่งพื้นฐาน เช่น pinMode, millis และ Serial
#include <ArduinoJson.h>       // สร้างและอ่านข้อมูล JSON ที่ส่งผ่าน MQTT
#include <ModbusMaster.h>      // ติดต่อรีเลย์ เซนเซอร์ และ HMI ผ่าน Modbus RTU
#include <Preferences.h>       // บันทึกค่าถาวรลงหน่วยความจำ NVS ของ ESP32
#include <PubSubClient.h>      // รับและส่งข้อความ MQTT
#include <WiFi.h>              // เชื่อมต่อ ESP32 เข้ากับ Wi-Fi
#include <WiFiClient.h>        // การเชื่อมต่อ TCP แบบทั่วไป
#include <WiFiClientSecure.h>  // การเชื่อมต่อแบบเข้ารหัส TLS
#include <Wire.h>              // บัส I2C สำหรับจอ LCD
#include <LiquidCrystal_I2C.h> // ควบคุมจอ LCD แบบ I2C
#include <time.h>              // เวลา วัน และตารางรดน้ำ

#include "config.h"           // ขา GPIO, Modbus, รีเลย์ และระบบความปลอดภัย
#include "secrets.h"          // Wi-Fi, MQTT และรหัสประจำตู้ (ต้องตรวจไฟล์นี้)
#include "wifi_override.h"    // Wi-Fi สำรอง/ค่าหน้างาน
#if defined(DEVICE_PROFILE_FBP0006)
#include "profiles/fbp0006.h"
#endif
#if defined(DEVICE_PROFILE_FBP0009)
#include "profiles/fbp0009.h"
#endif
#if defined(DEVICE_PROFILE_FBP0010)
#include "profiles/fbp0010.h"
#endif
#if defined(DEVICE_PROFILE_FBP0011)
#include "profiles/fbp0011.h"
#endif
#if defined(DEVICE_PROFILE_FBP0012)
#include "profiles/fbp0012.h"
#endif
#if defined(DEVICE_PROFILE_FBP0013)
#include "profiles/fbp0013.h"
#endif
#if defined(DEVICE_PROFILE_FB0007)
#include "profiles/fb0007.h"
#endif
#if defined(DEVICE_PROFILE_FB0008)
#include "profiles/fb0008.h"
#endif

#if defined(LCD_STANDALONE_TEST) && LCD_STANDALONE_TEST

LiquidCrystal_PCF8574 lcdPcf(0x27);

bool scanLcdOnly(uint8_t sda, uint8_t scl) {
  Serial.printf("I2C scanner SDA=%u SCL=%u\n", sda, scl);
  Wire.end();
  pinMode(sda, INPUT_PULLUP);
  pinMode(scl, INPUT_PULLUP);
  delay(50);
  Wire.begin(sda, scl);
  Wire.setClock(25000);
  Wire.setTimeOut(50);
  bool found = false;
  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
      Serial.printf("I2C found 0x%02X\n", address);
      found = true;
    }
  }
  if (!found) Serial.println("I2C found nothing");
  return found;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println();
  Serial.println("LCD STANDALONE TEST");

  bool foundStraight = scanLcdOnly(8, 9);
  bool foundSwapped = false;
  if (!foundStraight) {
    foundSwapped = scanLcdOnly(9, 8);
  }
  if (!foundStraight && foundSwapped) {
    Serial.println("LCD wires appear swapped, using SDA=9 SCL=8");
    Wire.end();
    Wire.begin(9, 8);
  } else {
    Serial.println("Using SDA=8 SCL=9");
    Wire.end();
    Wire.begin(8, 9);
  }
  Wire.setClock(25000);
  Wire.setTimeOut(50);

  lcdPcf.begin(20, 4);
  lcdPcf.setBacklight(255);
  lcdPcf.home();
  lcdPcf.clear();
  lcdPcf.setCursor(0, 0);
  lcdPcf.print("PCF8574 TEST");
  lcdPcf.setCursor(0, 1);
  lcdPcf.print("ADDR 0x27");
  lcdPcf.setCursor(0, 2);
  lcdPcf.print("SDA8 SCL9");
  lcdPcf.setCursor(0, 3);
  lcdPcf.print("HELLO SMART FARM");
  Serial.println("PCF8574 LCD write done");
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last >= 1000) {
    last = millis();
    scanLcdOnly(8, 9);
    scanLcdOnly(9, 8);
    Wire.end();
    Wire.begin(8, 9);
    lcdPcf.setCursor(0, 3);
    lcdPcf.print("UP ");
    lcdPcf.print(millis() / 1000);
    lcdPcf.print(" sec        ");
    Serial.println("tick");
  }
}

#else

// สร้างพอร์ต UART2 สำหรับ RS485 และตัวแทนอุปกรณ์ Modbus แต่ละตัว
HardwareSerial RS485Serial(2);
ModbusMaster node1;  // Relay 12CH
ModbusMaster node2;  // Installed soil 7-in-1 (moisture, temp, EC, pH, N, P, K, SAL)
ModbusMaster node3;  // Legacy soil node (not polled)
ModbusMaster node4;  // Legacy NPK node (not polled)
ModbusMaster nodeHmi;  // Kinseal HMI (Modbus RTU slave)
ModbusMaster scanNode;
Preferences preferences;

#if MQTT_ALLOW_PUBLIC_BROKER
WiFiClient mqttNetworkClient;
#else
WiFiClientSecure mqttNetworkClient;
#endif
PubSubClient mqtt(mqttNetworkClient);

// เก็บชื่อ ช่อง สถานะ และเวลาปิดอัตโนมัติของรีเลย์หนึ่งช่อง
struct RelayOutput {
  const char *name;
  uint8_t channel;
  bool enabled;
  unsigned long autoOffAt;
};

enum class RelayWriteResult : uint8_t { Confirmed, SentUnconfirmed, Failed };

RelayOutput pumpWater = {"pumpWater", RELAY_PUMP_WATER, false, 0};
RelayOutput pumpFertilizer = {"pumpFertilizer", RELAY_PUMP_FERTILIZER, false, 0};
RelayOutput zones[] = {
    {"zone1", RELAY_ZONE_1, false, 0},
    {"zone2", RELAY_ZONE_2, false, 0},
    {"zone3", RELAY_ZONE_3, false, 0},
    {"zone4", RELAY_ZONE_4, false, 0},
};

// รวมค่าจากเซนเซอร์ ค่า NAN หมายถึงยังไม่มีค่าที่เชื่อถือได้
struct SensorValues {
  bool node2Online = false;
  bool node3Online = false;
  bool node4Online = false;
  uint8_t node2Errors = 0;
  uint8_t node3Errors = 0;
  uint8_t node4Errors = 0;
  unsigned long node2LastReadMs = 0;
  unsigned long node3LastReadMs = 0;
  unsigned long node4LastReadMs = 0;
  float node2Humidity = NAN;
  float node2Temperature = NAN;
  float lux = NAN;
  float soilMoisture = NAN;
  float soilTemperature = NAN;
  float ec = NAN;
  float ph = NAN;
  float nitrogen = NAN;
  float phosphorus = NAN;
  float potassium = NAN;
  float salinity = NAN;
};

SensorValues sensors;
uint8_t relayNodeId = RELAY_NODE_ID;
uint8_t sensor3In1NodeId = SENSOR_3IN1_NODE_ID;
uint8_t soil4In1NodeId = SOIL_4IN1_NODE_ID;
uint8_t npkNodeId = NPK_NODE_ID;
uint32_t modbusBaudRate = MODBUS_BAUDRATE;
uint16_t node2HumidityReg = NODE2_HUMI_REG;
uint16_t node2TemperatureReg = NODE2_TEMP_REG;
uint16_t node2LuxReg = NODE2_LUX_REG;
uint16_t node3SoilReg = NODE3_SOIL_REG;
uint16_t node3TemperatureReg = NODE3_TEMP_REG;
uint16_t node3EcReg = NODE3_EC_REG;
uint16_t node3PhReg = NODE3_PH_REG;
uint16_t node4NReg = NODE4_N_REG;
uint16_t node4PReg = NODE4_P_REG;
uint16_t node4KReg = NODE4_K_REG;
bool autoModeEnabled = false;
float autoMinMoisture = 35.0f;
float autoMaxMoisture = 75.0f;
uint32_t autoMaxRuntimeSeconds = 30UL * 60UL;
bool autoRainSkip = true;
bool autoFlowProtection = false;
bool autoDryRunProtection = false;
bool autoWaterLevelProtection = false;
bool autoFailSafeOnSensorLoss = true;
uint8_t autoZoneMask = 0x0F;
uint16_t autoCooldownMinutes = 20;
uint16_t autoDailyRuntimeLimitMinutes = 120;
uint8_t nextAutoZone = 0;
unsigned long lastAutoStopAt = 0;
unsigned long autoCycleStartedAt = 0;
unsigned long lastAutoLimitAlarmAt = 0;
uint32_t autoDailyRuntimeSeconds = 0;
int autoRuntimeDay = -1;
enum class IrrigationSource : uint8_t { None, Manual, Auto, Schedule };
IrrigationSource irrigationSource = IrrigationSource::None;
float flowRate = NAN;
float waterLevel = NAN;
bool rainDetected = false;
unsigned long lastTelemetryAt = 0;
unsigned long lastSensorPollAt = 0;
unsigned long lastRelayFeedbackPollAt = 0;
unsigned long lastHmiSyncAt = 0;
unsigned long nextHmiRetryAt = 0;
bool hmiOnline = false;
bool hmiStateInitialized = false;
bool relayFeedbackAvailable = false;
bool lastCommandHadUnconfirmedRelayWrite = false;
unsigned long nextMqttReconnectAt = 0;
unsigned long nextWifiReconnectAt = 0;
unsigned long wifiAttemptStartedAt = 0;
unsigned long lastAutoCheckAt = 0;
unsigned long pumpWaterStartedAt = 0;
uint32_t wifiConnectAttempts = 0;
uint32_t mqttConnectAttempts = 0;
uint32_t wifiDisconnectCount = 0;
uint32_t mqttDisconnectCount = 0;
uint8_t wifiFailureStreak = 0;
uint8_t mqttFailureStreak = 0;
int lastScheduleMinute = -1;
bool wifiReconnectRequested = false;
bool wifiAttemptInProgress = false;
bool wifiWasConnected = false;
bool mqttWasConnected = false;
bool lcdReady = false;
uint8_t lcdAddress = 0;
uint8_t lcdSdaPin = 255;
uint8_t lcdSclPin = 255;
uint8_t lcdPage = 0;
unsigned long lastLcdUpdateAt = 0;
unsigned long lastLcdPageAt = 0;
LiquidCrystal_I2C lcd(LCD_I2C_ADDRESS, LCD_COLUMNS, LCD_ROWS);

struct LcdMapping {
  const char *name;
  uint8_t rs;
  uint8_t en;
  uint8_t d4;
  uint8_t d5;
  uint8_t d6;
  uint8_t d7;
  uint8_t bl;
  bool backlightOnHigh;
};

const LcdMapping LCD_MAPPINGS[] = {
    {"YWROBOT H", 0, 2, 4, 5, 6, 7, 3, true},
    {"YWROBOT L", 0, 2, 4, 5, 6, 7, 3, false},
    {"MJKDZ L", 6, 4, 0, 1, 2, 3, 7, false},
    {"MJKDZ H", 6, 4, 0, 1, 2, 3, 7, true},
    {"LCDXIO", 4, 6, 0, 1, 2, 3, 7, true},
    {"LCDXIO L", 4, 6, 0, 1, 2, 3, 7, false},
};

const LcdMapping *activeLcdMapping = nullptr;

String runtimeWifiSsid;
String runtimeWifiPassword;

String commandTopic;
String telemetryTopic;
String statusTopic;
String alarmTopic;
String ackTopic;

struct CommandAckCacheEntry {
  String commandId;
  String status;
  String message;
};

constexpr uint8_t COMMAND_ACK_CACHE_SIZE = 16;
CommandAckCacheEntry commandAckCache[COMMAND_ACK_CACHE_SIZE];
uint8_t commandAckCacheCursor = 0;

void setupModbus();
void configureMqttServer();
uint16_t modbusCrc(const uint8_t *data, uint8_t length);
bool rawModbusRead(uint8_t id, uint8_t functionCode, uint16_t startReg, uint16_t count, uint8_t *response, uint8_t &responseLength);

struct ScheduleItem {
  bool enabled;
  uint8_t zone;
  uint16_t startMinute;
  uint16_t durationMinutes;
  uint8_t daysMask;
  bool running;
};

constexpr uint8_t MAX_SCHEDULES = 8;
ScheduleItem schedules[MAX_SCHEDULES];
uint8_t scheduleCount = 0;

String timestampText() {
  struct tm timeinfo;
  if (getLocalTime(&timeinfo, 10)) {
    char buffer[32];
    strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%S+07:00", &timeinfo);
    return String(buffer);
  }

  return String("uptime:") + String(millis() / 1000UL);
}

bool timeReached(unsigned long target) {
  return target == 0 || static_cast<long>(millis() - target) >= 0;
}

unsigned long reconnectDelay(unsigned long minimum, unsigned long maximum, uint8_t failures) {
  uint8_t shift = failures > 5 ? 5 : failures;
  unsigned long delayMs = minimum << shift;
  if (delayMs > maximum) delayMs = maximum;
  return delayMs + static_cast<unsigned long>(random(0, 750));
}

uint8_t lcdMapByte(uint8_t nibble, bool dataMode, const LcdMapping &mapping) {
  uint8_t value = 0;
  if (dataMode) value |= (1 << mapping.rs);
  if (nibble & 0x01) value |= (1 << mapping.d4);
  if (nibble & 0x02) value |= (1 << mapping.d5);
  if (nibble & 0x04) value |= (1 << mapping.d6);
  if (nibble & 0x08) value |= (1 << mapping.d7);
  const bool hasBacklight = mapping.bl < 8;
  if (hasBacklight && mapping.backlightOnHigh) value |= (1 << mapping.bl);
  return value;
}

void lcdRawWriteExpander(uint8_t value, const LcdMapping &mapping) {
  if (mapping.bl < 8 && !mapping.backlightOnHigh) {
    value &= ~(1 << mapping.bl);
  }
  Wire.beginTransmission(lcdAddress ? lcdAddress : LCD_I2C_ADDRESS);
  Wire.write(value);
  Wire.endTransmission();
}

void lcdRawPulse(uint8_t value, const LcdMapping &mapping) {
  lcdRawWriteExpander(value | (1 << mapping.en), mapping);
  delayMicroseconds(1);
  lcdRawWriteExpander(value & ~(1 << mapping.en), mapping);
  delayMicroseconds(50);
}

void lcdRawWrite4(uint8_t nibble, bool dataMode, const LcdMapping &mapping) {
  uint8_t value = lcdMapByte(nibble, dataMode, mapping);
  lcdRawWriteExpander(value, mapping);
  lcdRawPulse(value, mapping);
}

void lcdRawSend(uint8_t value, bool dataMode, const LcdMapping &mapping) {
  lcdRawWrite4(value >> 4, dataMode, mapping);
  lcdRawWrite4(value & 0x0F, dataMode, mapping);
}

void lcdRawCommand(uint8_t value, const LcdMapping &mapping) {
  lcdRawSend(value, false, mapping);
}

void lcdRawClear(const LcdMapping &mapping) {
  lcdRawCommand(0x01, mapping);
  delay(3);
}

void lcdRawSetCursor(uint8_t col, uint8_t row, const LcdMapping &mapping) {
  static const uint8_t rowOffsets[] = {0x00, 0x40, 0x14, 0x54};
  if (row >= LCD_ROWS) return;
  lcdRawCommand(0x80 | (col + rowOffsets[row]), mapping);
}

void lcdRawPrintFixed(uint8_t row, const String &text, const LcdMapping &mapping) {
  lcdRawSetCursor(0, row, mapping);
  String line = text.substring(0, LCD_COLUMNS);
  while (line.length() < LCD_COLUMNS) line += ' ';
  for (uint8_t i = 0; i < LCD_COLUMNS; i++) {
    lcdRawSend(static_cast<uint8_t>(line[i]), true, mapping);
  }
}

bool lcdRawBegin(const LcdMapping &mapping) {
  delay(60);
  lcdRawWriteExpander(lcdMapByte(0, false, mapping), mapping);
  delay(10);
  lcdRawWrite4(0x03, false, mapping);
  delay(5);
  lcdRawWrite4(0x03, false, mapping);
  delayMicroseconds(200);
  lcdRawWrite4(0x03, false, mapping);
  delayMicroseconds(200);
  lcdRawWrite4(0x02, false, mapping);
  delayMicroseconds(200);

  lcdRawCommand(0x28, mapping);
  lcdRawCommand(0x08, mapping);
  lcdRawClear(mapping);
  lcdRawCommand(0x06, mapping);
  lcdRawCommand(0x0C, mapping);
  return true;
}

bool probeLcdMappings() {
#if LCD_MAPPING_PROBE_ON_BOOT
  Serial.println("LCD mapping probe start");
  for (const LcdMapping &mapping : LCD_MAPPINGS) {
    Serial.printf("Trying LCD mapping: %s\n", mapping.name);
    lcdRawBegin(mapping);
    lcdRawPrintFixed(0, String("MAP ") + mapping.name, mapping);
    lcdRawPrintFixed(1, "If visible wait...", mapping);
    lcdRawPrintFixed(2, "Smart Farm LCD", mapping);
    lcdRawPrintFixed(3, "20x4 addr 0x27", mapping);
    delay(2500);
  }

  activeLcdMapping = &LCD_MAPPINGS[0];
  lcdRawBegin(*activeLcdMapping);
  lcdRawPrintFixed(0, "MAP YWROBOT H", *activeLcdMapping);
  lcdRawPrintFixed(1, "Selected default", *activeLcdMapping);
  lcdRawPrintFixed(2, "Tell if visible", *activeLcdMapping);
  lcdRawPrintFixed(3, "Boot continues...", *activeLcdMapping);
  delay(1500);
  return true;
#else
  return false;
#endif
}

void lcdClear() {
  if (!lcdReady) return;
  if (activeLcdMapping) {
    lcdRawClear(*activeLcdMapping);
    return;
  }
  lcd.clear();
}

void lcdSetCursor(uint8_t col, uint8_t row) {
  if (!lcdReady || row >= LCD_ROWS) return;
  if (activeLcdMapping) {
    lcdRawSetCursor(col, row, *activeLcdMapping);
    return;
  }
  lcd.setCursor(col, row);
}

void lcdPrintFixed(uint8_t row, const String &text) {
  if (!lcdReady || row >= LCD_ROWS) return;
  lcdSetCursor(0, row);
  String line = text.substring(0, LCD_COLUMNS);
  while (line.length() < LCD_COLUMNS) line += ' ';
  if (activeLcdMapping) {
    for (uint8_t i = 0; i < LCD_COLUMNS; i++) {
      lcdRawSend(static_cast<uint8_t>(line[i]), true, *activeLcdMapping);
    }
  } else {
    lcd.print(line);
  }
}

String fmtFloat(float value, uint8_t decimals, const char *missing = "--") {
  if (isnan(value)) return String(missing);
  return String(value, static_cast<unsigned int>(decimals));
}

String zoneText() {
  String text = "";
  for (uint8_t i = 0; i < 4; i++) {
    text += zones[i].enabled ? String(i + 1) : "-";
  }
  return text;
}

uint8_t onboardRelayPin(uint8_t channel) {
  const uint8_t pins[] = {
      ONBOARD_RELAY_CH1_PIN,
      ONBOARD_RELAY_CH2_PIN,
      ONBOARD_RELAY_CH3_PIN,
      ONBOARD_RELAY_CH4_PIN,
      ONBOARD_RELAY_CH5_PIN,
      ONBOARD_RELAY_CH6_PIN,
  };
  return channel >= 1 && channel <= 6 ? pins[channel - 1] : 255;
}

void lockOnboardRelaysOff() {
#if ONBOARD_RELAY_CONTROL_ENABLED
  static bool initialized = false;
  if (initialized) return;
  initialized = true;
  for (uint8_t channel = 1; channel <= 6; channel++) {
    uint8_t pin = onboardRelayPin(channel);
    digitalWrite(pin, ONBOARD_RELAY_OFF_LEVEL);
    pinMode(pin, OUTPUT);
    digitalWrite(pin, ONBOARD_RELAY_OFF_LEVEL);
  }
#elif ONBOARD_RELAY_LOCK_OFF
  const uint8_t pins[] = {
      ONBOARD_RELAY_CH1_PIN,
      ONBOARD_RELAY_CH2_PIN,
      ONBOARD_RELAY_CH3_PIN,
      ONBOARD_RELAY_CH4_PIN,
      ONBOARD_RELAY_CH5_PIN,
      ONBOARD_RELAY_CH6_PIN,
  };
  for (uint8_t pin : pins) {
    if (pin == lcdSdaPin || pin == lcdSclPin) continue;
    digitalWrite(pin, ONBOARD_RELAY_OFF_LEVEL);
    pinMode(pin, OUTPUT);
    digitalWrite(pin, ONBOARD_RELAY_OFF_LEVEL);
  }
#endif
}

uint8_t scanLcdAddress() {
  Serial.println("I2C scan start");
  uint8_t firstAddress = 0;
  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
      Serial.printf("I2C device found at 0x%02X\n", address);
      if (address == 0x27 || address == 0x3F) return address;
      if (firstAddress == 0) firstAddress = address;
    }
  }
  if (firstAddress == 0) Serial.println("I2C scan found no devices");
  return firstAddress;
}

void setupLcd() {
#if LCD_I2C_ENABLED
  lcdSdaPin = LCD_SDA_PIN;
  lcdSclPin = LCD_SCL_PIN;
  Wire.end();
  pinMode(lcdSdaPin, INPUT_PULLUP);
  pinMode(lcdSclPin, INPUT_PULLUP);
  delay(50);
  Wire.begin(lcdSdaPin, lcdSclPin);
  Wire.setTimeOut(20);
  Wire.setClock(25000);
  lcdAddress = scanLcdAddress();
  if (lcdAddress == 0) {
    lcdAddress = LCD_I2C_ADDRESS;
    Serial.printf("LCD scan missed device, forcing addr=0x%02X on SDA=%u SCL=%u\n", lcdAddress, lcdSdaPin, lcdSclPin);
  }
  if (lcdAddress != LCD_I2C_ADDRESS) {
    Serial.printf("LCD warning: detected 0x%02X but configured 0x%02X\n", lcdAddress, LCD_I2C_ADDRESS);
  }

  if (probeLcdMappings()) {
    lcdReady = true;
    Serial.printf("LCD manual driver ready at 0x%02X on SDA=%u SCL=%u\n", lcdAddress, lcdSdaPin, lcdSclPin);
    return;
  }

  // ไลบรารี LiquidCrystal_I2C ของเครื่องนี้รับขนาดจอจาก constructor ด้านบนแล้ว
  // จึงเรียก begin() โดยไม่ส่งจำนวนคอลัมน์/แถวซ้ำ
  lcd.begin();
  lcd.backlight();

  lcdReady = true;
  lcdClear();

  lcd.noBacklight();
  delay(200);
  lcd.backlight();
  lcdPrintFixed(0, "RS485 SCANNER");
  lcdPrintFixed(1, "Start...");
  delay(2000);
  Serial.printf("LiquidCrystal_I2C ready at 0x%02X on SDA=%u SCL=%u\n", lcdAddress, lcdSdaPin, lcdSclPin);
#endif
}

void updateLcd() {
  if (!lcdReady) return;

  unsigned long now = millis();
  if (now - lastLcdPageAt >= LCD_PAGE_INTERVAL_MS) {
    lastLcdPageAt = now;
    lcdPage = (lcdPage + 1) % 4;
  }
  if (now - lastLcdUpdateAt < 1000UL) return;
  lastLcdUpdateAt = now;

  const bool wifiOk = WiFi.isConnected();
  const bool mqttOk = mqtt.connected();

  if (lcdPage == 0) {
    lcdPrintFixed(0, String("SmartFarm ") + (mqttOk ? "ONLINE" : wifiOk ? "WIFI" : "OFFLINE"));
    lcdPrintFixed(1, String("Mode ") + (autoModeEnabled ? "AUTO" : "MANUAL"));
    lcdPrintFixed(2, String("Pump ") + (pumpWater.enabled ? "ON " : "OFF") + " Z:" + zoneText());
    lcdPrintFixed(3, String("MQTT ") + (mqttOk ? "OK" : "ERR") + " WiFi " + (wifiOk ? "OK" : "ERR"));
    return;
  }

  if (lcdPage == 1) {
    lcdPrintFixed(0, "Air " + fmtFloat(sensors.node2Humidity, 1) + "% " + fmtFloat(sensors.node2Temperature, 1) + "C");
    lcdPrintFixed(1, "Soil " + fmtFloat(sensors.soilMoisture, 1) + "% " + fmtFloat(sensors.soilTemperature, 1) + "C");
    lcdPrintFixed(2, "EC " + fmtFloat(sensors.ec, 0) + " pH " + fmtFloat(sensors.ph, 1));
    lcdPrintFixed(3, "Lux " + fmtFloat(sensors.lux, 0));
    return;
  }

  if (lcdPage == 2) {
    lcdPrintFixed(0, "NPK " + fmtFloat(sensors.nitrogen, 0) + "/" + fmtFloat(sensors.phosphorus, 0) + "/" + fmtFloat(sensors.potassium, 0));
    lcdPrintFixed(1, "Water " + fmtFloat(waterLevel, 0) + "%");
    lcdPrintFixed(2, "Flow " + fmtFloat(flowRate, 1) + " L/m");
    lcdPrintFixed(3, String("Rain ") + (rainDetected ? "YES" : "NO ") + " Err " + String(sensors.node2Errors + sensors.node3Errors + sensors.node4Errors));
    return;
  }

  lcdPrintFixed(0, "CPRU");
  lcdPrintFixed(1, "DR.SAMART SINTON");
  lcdPrintFixed(2, "TEL 0807999907");
  lcdPrintFixed(3, "BANANA FARM");
}

// แปลงข้อมูลเป็น JSON แล้วส่งไปยัง MQTT topic ที่กำหนด
void publishJson(const String &topic, JsonDocument &doc, bool retained = false) {
  char buffer[1536];
  size_t len = serializeJson(doc, buffer);
  bool ok = mqtt.connected()
      && mqtt.publish(topic.c_str(), reinterpret_cast<const uint8_t *>(buffer), len, retained);
  Serial.printf("MQTT publish %s: %s\n", topic.c_str(), ok ? "ok" : "failed");
}

void publishAlarm(const char *type, const char *message, const char *severity = "critical") {
  JsonDocument doc;
  doc["id"] = String(type) + "-" + String(millis());
  doc["type"] = type;
  doc["message"] = message;
  doc["severity"] = severity;
  doc["createdAt"] = timestampText();
  doc["acknowledged"] = false;
  publishJson(alarmTopic, doc);
}

void publishCommandAck(const char *commandId, const char *status, const char *message) {
  if (commandId == nullptr || strlen(commandId) == 0) return;
  JsonDocument doc;
  doc["commandId"] = commandId;
  doc["status"] = status;
  doc["message"] = message;
  doc["createdAt"] = timestampText();
  publishJson(ackTopic, doc);
}

bool publishCachedCommandAck(const char *commandId) {
  if (commandId == nullptr || strlen(commandId) == 0) return false;
  for (const auto &entry : commandAckCache) {
    if (entry.commandId == commandId) {
      publishCommandAck(entry.commandId.c_str(), entry.status.c_str(), entry.message.c_str());
      return true;
    }
  }
  return false;
}

void rememberCommandAck(const char *commandId, const char *status, const String &message) {
  if (commandId == nullptr || strlen(commandId) == 0) return;
  CommandAckCacheEntry &entry = commandAckCache[commandAckCacheCursor];
  entry.commandId = commandId;
  entry.status = status;
  entry.message = message;
  commandAckCacheCursor = (commandAckCacheCursor + 1) % COMMAND_ACK_CACHE_SIZE;
}

RelayWriteResult sendRelayFrame(const uint8_t *request, uint8_t requestLength, const uint8_t *expectedReply, uint8_t expectedReplyLength) {
  while (RS485Serial.available()) RS485Serial.read();
  size_t written = RS485Serial.write(request, requestLength);
  RS485Serial.flush();
  if (written != requestLength) return RelayWriteResult::Failed;

  uint8_t response[16];
  uint8_t responseLength = 0;
  unsigned long startedAt = millis();
  while (millis() - startedAt < RELAY_REPLY_WINDOW_MS && responseLength < sizeof(response)) {
    if (RS485Serial.available()) response[responseLength++] = RS485Serial.read();
    else delay(1);
  }

  if (responseLength == expectedReplyLength && memcmp(response, expectedReply, expectedReplyLength) == 0) {
    return RelayWriteResult::Confirmed;
  }
  return RelayWriteResult::SentUnconfirmed;
}

// ส่งคำสั่ง Modbus เพื่อเปิด/ปิดรีเลย์หนึ่งช่อง และตรวจผลตอบกลับ
RelayWriteResult writeRelay(uint8_t channel, bool enabled) {
  if (channel == 0) {
    Serial.printf("Relay virtual %s skipped\n", enabled ? "ON" : "OFF");
    return RelayWriteResult::Confirmed;
  }
  if (channel < 1 || channel > 12) {
    Serial.printf("Invalid relay channel: %u\n", channel);
    return RelayWriteResult::Failed;
  }

#if ONBOARD_RELAY_CONTROL_ENABLED
  uint8_t onboardPin = onboardRelayPin(channel);
  if (onboardPin != 255) {
    uint8_t level = enabled ? ONBOARD_RELAY_ON_LEVEL : ONBOARD_RELAY_OFF_LEVEL;
    digitalWrite(onboardPin, level);
    bool confirmed = digitalRead(onboardPin) == level;
    Serial.printf("Relay CH%u %s -> onboard GPIO%u %s\n", channel, enabled ? "ON" : "OFF", onboardPin, confirmed ? "confirmed" : "failed");
    return confirmed ? RelayWriteResult::Confirmed : RelayWriteResult::Failed;
  }
#endif

  uint16_t coilAddress = channel - 1;
  uint8_t request[8] = {
      relayNodeId,
      0x05,
      static_cast<uint8_t>(coilAddress >> 8),
      static_cast<uint8_t>(coilAddress & 0xFF),
      static_cast<uint8_t>(enabled ? 0xFF : 0x00),
      0x00,
      0,
      0,
  };
  uint16_t crc = modbusCrc(request, 6);
  request[6] = crc & 0xFF;
  request[7] = crc >> 8;
  RelayWriteResult result = sendRelayFrame(request, sizeof(request), request, sizeof(request));
  if (result == RelayWriteResult::SentUnconfirmed) {
    lastCommandHadUnconfirmedRelayWrite = true;
    Serial.printf("Relay CH%u %s sent without reply; keeping commanded state\n", channel, enabled ? "ON" : "OFF");
  } else {
    Serial.printf("Relay CH%u %s confirmed\n", channel, enabled ? "ON" : "OFF");
  }
  return result;
}

RelayWriteResult sendEmergencyZonesOff() {
  uint8_t request[10] = {relayNodeId, 0x0F, 0x00, 0x00, 0x00, 0x04, 0x01, 0x00, 0, 0};
  uint16_t requestCrc = modbusCrc(request, 8);
  request[8] = requestCrc & 0xFF;
  request[9] = requestCrc >> 8;

  uint8_t expectedReply[8] = {relayNodeId, 0x0F, 0x00, 0x00, 0x00, 0x04, 0, 0};
  uint16_t replyCrc = modbusCrc(expectedReply, 6);
  expectedReply[6] = replyCrc & 0xFF;
  expectedReply[7] = replyCrc >> 8;

  RelayWriteResult result = RelayWriteResult::Failed;
  for (uint8_t attempt = 0; attempt < EMERGENCY_OFF_RETRIES; attempt++) {
    RelayWriteResult attemptResult = sendRelayFrame(request, sizeof(request), expectedReply, sizeof(expectedReply));
    if (attemptResult == RelayWriteResult::Confirmed) return attemptResult;
    if (attemptResult == RelayWriteResult::SentUnconfirmed) result = attemptResult;
    if (attempt + 1 < EMERGENCY_OFF_RETRIES) delay(EMERGENCY_OFF_RETRY_DELAY_MS);
  }
  if (result == RelayWriteResult::SentUnconfirmed) lastCommandHadUnconfirmedRelayWrite = true;
  return result;
}

// เปลี่ยนสถานะรีเลย์พร้อมตั้งเวลาปิดอัตโนมัติ ป้องกันการเปิดค้าง
bool setRelay(RelayOutput &output, bool enabled, unsigned long autoOffSeconds = 0) {
  if (output.channel == 0) {
    output.enabled = false;
    output.autoOffAt = 0;
    if (&output == &pumpWater) pumpWaterStartedAt = 0;
    Serial.printf("Relay %s has no physical channel, skipped\n", output.name);
    return !enabled;
  }
  RelayWriteResult writeResult = writeRelay(output.channel, enabled);
  if (writeResult != RelayWriteResult::Failed) {
    output.enabled = enabled;
    output.autoOffAt = enabled && autoOffSeconds > 0 ? millis() + autoOffSeconds * 1000UL : 0;
    if (&output == &pumpWater) {
      pumpWaterStartedAt = enabled ? millis() : 0;
    }
    return true;
  } else {
    publishAlarm("relay_modbus_error", output.name, "warning");
    return false;
  }
}

uint32_t autoOffRemainingSeconds(const RelayOutput &output) {
  if (!output.enabled || output.autoOffAt == 0) return 0;
  long remainingMs = static_cast<long>(output.autoOffAt - millis());
  return remainingMs > 0 ? (static_cast<uint32_t>(remainingMs) + 999UL) / 1000UL : 0;
}

void publishTelemetry();
bool emergencyOutputsOff();
bool startWaterOutput(RelayOutput &zone, unsigned long autoOffSeconds, const char *source);
bool stopZoneAndMaybePump(uint8_t zoneIndex);

// Reconcile the software state with the relay board. This catches changes made
// by a local Modbus panel/HMI and also verifies that a commanded coil really
// changed. A board that does not implement function 0x01 simply keeps the
// existing command-confirmed state, so legacy installations continue to work.
void pollRelayFeedback() {
  static uint8_t failureStreak = 0;
  const unsigned long pollInterval = failureStreak >= 3 ? 300000UL : RELAY_FEEDBACK_POLL_INTERVAL_MS;
  if (millis() - lastRelayFeedbackPollAt < pollInterval) return;
  lastRelayFeedbackPollAt = millis();

#if ONBOARD_RELAY_CONTROL_ENABLED
  bool changed = false;
  RelayOutput *outputs[] = {&pumpWater, &pumpFertilizer, &zones[0], &zones[1], &zones[2], &zones[3]};
  for (auto *output : outputs) {
    uint8_t pin = onboardRelayPin(output->channel);
    if (pin == 255) continue;
    bool actual = digitalRead(pin) == ONBOARD_RELAY_ON_LEVEL;
    if (actual == output->enabled) continue;
    output->enabled = actual;
    output->autoOffAt = 0;
    if (output == &pumpWater) pumpWaterStartedAt = actual ? millis() : 0;
    changed = true;
  }
  if (changed) publishTelemetry();
  return;
#else
  uint8_t result = node1.readCoils(0, 12);
  if (result != node1.ku8MBSuccess) {
    bool feedbackChanged = relayFeedbackAvailable;
    relayFeedbackAvailable = false;
    if (failureStreak < 10) failureStreak++;
    if (MODBUS_DEBUG && (failureStreak == 1 || failureStreak == 3)) {
      Serial.printf("[MODBUS] relay feedback unavailable result=%u; using command-confirmed state\n", result);
    }
    if (feedbackChanged) publishTelemetry();
    return;
  }
  failureStreak = 0;
  bool feedbackChanged = !relayFeedbackAvailable;
  relayFeedbackAvailable = true;

  bool changed = false;
  RelayOutput *outputs[] = {&pumpWater, &pumpFertilizer, &zones[0], &zones[1], &zones[2], &zones[3]};
  for (auto *output : outputs) {
    if (output->channel < 1 || output->channel > 12) continue;
    uint8_t coilIndex = output->channel - 1;
    bool actual = (node1.getResponseBuffer(coilIndex / 16) & (1U << (coilIndex % 16))) != 0;
    if (actual == output->enabled) continue;

    output->enabled = actual;
    output->autoOffAt = actual ? millis() + LOCAL_RELAY_AUTO_OFF_SECONDS * 1000UL : 0;
    if (output == &pumpWater) pumpWaterStartedAt = actual ? millis() : 0;
    changed = true;
    Serial.printf("Relay feedback %s -> %s\n", output->name, actual ? "ON" : "OFF");
  }

  if (changed || feedbackChanged) publishTelemetry();
#endif
}

bool hasNumber(float value) {
  return !isnan(value);
}

bool anyZoneEnabled() {
  for (auto &zone : zones) {
    if (zone.enabled) return true;
  }
  return false;
}

uint16_t hmiScaledValue(float value, float scale = 1.0f) {
  if (!hasNumber(value)) return 0;
  float scaled = value * scale;
  if (scaled < 0) return static_cast<uint16_t>(static_cast<int16_t>(scaled));
  return static_cast<uint16_t>(min(scaled, 65535.0f));
}

uint8_t activeZoneCount() {
  uint8_t count = 0;
  for (const auto &zone : zones) {
    if (zone.enabled) count++;
  }
  return count;
}

bool writeHmiZoneState() {
  for (uint8_t index = 0; index < 4; index++) {
    if (nodeHmi.writeSingleCoil(index, zones[index].enabled ? 1 : 0) != nodeHmi.ku8MBSuccess) {
      return false;
    }
  }
  // LB7 is a momentary emergency-stop request. Always return it to OFF.
  return nodeHmi.writeSingleCoil(7, 0) == nodeHmi.ku8MBSuccess;
}

bool writeHmiTelemetry() {
  const uint16_t values[] = {
      hmiScaledValue(sensors.soilMoisture, 10.0f),  // LW0, 0.1 %
      hmiScaledValue(sensors.node2Temperature, 10.0f),  // LW1, 0.1 C
      hmiScaledValue(sensors.node2Humidity, 10.0f),  // LW2, 0.1 %RH
      hmiScaledValue(sensors.ec),  // LW3, uS/cm
      hmiScaledValue(sensors.ph, 10.0f),  // LW4, 0.1 pH
      activeZoneCount(),  // LW5
      static_cast<uint16_t>((sensors.node2Online ? 1 : 0)
          | (sensors.node3Online ? 2 : 0)
          | (sensors.node4Online ? 4 : 0)),  // LW6 sensor status mask
      static_cast<uint16_t>(autoModeEnabled ? 1 : 0),  // LW7
      hmiScaledValue(sensors.lux),  // LW8, lux
      hmiScaledValue(sensors.soilTemperature, 10.0f),  // LW9, 0.1 C
      hmiScaledValue(sensors.nitrogen),  // LW10, mg/kg
      hmiScaledValue(sensors.phosphorus),  // LW11, mg/kg
      hmiScaledValue(sensors.potassium),  // LW12, mg/kg
      hmiScaledValue(flowRate, 10.0f),  // LW13, 0.1 L/min (optional sensor)
      hmiScaledValue(waterLevel, 10.0f),  // LW14, 0.1 % (optional sensor)
      static_cast<uint16_t>(rainDetected ? 1 : 0),  // LW15, optional rain sensor
      hmiScaledValue(sensors.salinity),  // LW16, soil salinity (SAL), mg/L
  };
  nodeHmi.clearTransmitBuffer();
  for (uint8_t index = 0; index < sizeof(values) / sizeof(values[0]); index++) {
    nodeHmi.setTransmitBuffer(index, values[index]);
  }
  return nodeHmi.writeMultipleRegisters(0, sizeof(values) / sizeof(values[0])) == nodeHmi.ku8MBSuccess;
}

void syncHmi() {
#if HMI_MODBUS_ENABLED
  unsigned long now = millis();
  if (now - lastHmiSyncAt < HMI_SYNC_INTERVAL_MS || now < nextHmiRetryAt) return;
  lastHmiSyncAt = now;

  uint8_t result = nodeHmi.readCoils(0, 8);
  if (result != nodeHmi.ku8MBSuccess) {
    if (hmiOnline) Serial.printf("[HMI] offline result=%u\n", result);
    hmiOnline = false;
    hmiStateInitialized = false;
    nextHmiRetryAt = now + HMI_OFFLINE_RETRY_MS;
    return;
  }

  bool requestedZones[4];
  uint16_t commandBits = nodeHmi.getResponseBuffer(0);
  for (uint8_t index = 0; index < 4; index++) {
    requestedZones[index] = (commandBits & (1U << index)) != 0;
  }
  bool emergencyStopRequested = (commandBits & (1U << 7)) != 0;

  if (!hmiOnline) Serial.println("[HMI] Modbus panel online");
  hmiOnline = true;

  // On first contact, publish controller state before accepting panel input.
  // This prevents a freshly booted HMI (all local bits are zero) from silently
  // overriding outputs that were started by a schedule or the web dashboard.
  if (!hmiStateInitialized) {
    if (writeHmiZoneState()) hmiStateInitialized = true;
    writeHmiTelemetry();
    return;
  }

  bool changed = false;
  if (emergencyStopRequested) {
    emergencyOutputsOff();
    publishAlarm("emergency_stop", "Emergency stop activated from local HMI", "critical");
    changed = true;
  } else {
    for (uint8_t index = 0; index < 4; index++) {
      if (requestedZones[index] == zones[index].enabled) continue;
      bool ok = requestedZones[index]
          ? startWaterOutput(zones[index], HMI_LOCAL_CONTROL_MAX_SECONDS, "local HMI")
          : stopZoneAndMaybePump(index);
      changed = changed || ok;
    }
  }

  bool stateWritten = writeHmiZoneState();
  bool telemetryWritten = writeHmiTelemetry();
  if (!stateWritten || !telemetryWritten) {
    hmiOnline = false;
    hmiStateInitialized = false;
    nextHmiRetryAt = millis() + HMI_OFFLINE_RETRY_MS;
  }
  if (changed) publishTelemetry();
#endif
}

bool canStartIrrigation(const char *source) {
  if (autoWaterLevelProtection) {
    if (!hasNumber(waterLevel) && autoFailSafeOnSensorLoss) {
      publishAlarm("sensor_disconnected", "Water level sensor is unavailable", "critical");
      return false;
    }
    if (hasNumber(waterLevel) && waterLevel < MIN_SAFE_WATER_LEVEL_PERCENT) {
      publishAlarm("water_level_low", source, "critical");
      return false;
    }
  }

  if (autoRainSkip && rainDetected) {
    publishAlarm("rain_skip", source, "warning");
    return false;
  }

  return true;
}

bool startWaterOutput(RelayOutput &zone, unsigned long autoOffSeconds, const char *source) {
  if (!canStartIrrigation(source)) {
    return false;
  }

  if (!setRelay(zone, true, autoOffSeconds)) {
    return false;
  }

  if (pumpWater.channel > 0) {
    if (!pumpWater.enabled) {
      delay(WATER_PATH_SETTLE_DELAY_MS);
      if (!setRelay(pumpWater, true, autoOffSeconds)) {
        setRelay(zone, false);
        return false;
      }
    } else if (autoOffSeconds > 0) {
      // A newly opened zone must not outlive the shared water pump timer.
      pumpWater.autoOffAt = millis() + autoOffSeconds * 1000UL;
    }
  }
  if (zone.enabled) {
    irrigationSource = strstr(source, "auto mode") != nullptr
      ? IrrigationSource::Auto
      : strstr(source, "schedule") != nullptr ? IrrigationSource::Schedule : IrrigationSource::Manual;
    if (irrigationSource == IrrigationSource::Auto) autoCycleStartedAt = millis();
  }
  return zone.enabled;
}

bool stopZoneAndMaybePump(uint8_t zoneIndex) {
  if (zoneIndex >= 4) return false;
  bool anotherZoneEnabled = false;
  for (uint8_t index = 0; index < 4; index++) {
    if (index != zoneIndex && zones[index].enabled) {
      anotherZoneEnabled = true;
      break;
    }
  }
  if (pumpWater.channel > 0 && !anotherZoneEnabled && pumpWater.enabled) {
    if (pumpFertilizer.enabled && !setRelay(pumpFertilizer, false)) return false;
    if (!setRelay(pumpWater, false)) return false;
    delay(WATER_PATH_SETTLE_DELAY_MS);
  }
  return setRelay(zones[zoneIndex], false);
}

void applyRelayMap() {
  if (preferences.getUChar("relayMapVer", 0) < RELAY_MAPPING_VERSION) {
    preferences.putUChar("rPump", RELAY_PUMP_WATER);
    preferences.putUChar("rFert", RELAY_PUMP_FERTILIZER);
    preferences.putUChar("rZ1", RELAY_ZONE_1);
    preferences.putUChar("rZ2", RELAY_ZONE_2);
    preferences.putUChar("rZ3", RELAY_ZONE_3);
    preferences.putUChar("rZ4", RELAY_ZONE_4);
    preferences.putUChar("relayMapVer", RELAY_MAPPING_VERSION);
    Serial.println("Migrated relay map: cabinet pumps, RS485 zones CH1-CH4");
  }
  pumpWater.channel = RELAY_PUMP_WATER == 0 ? 0 : preferences.getUChar("rPump", RELAY_PUMP_WATER);
  pumpFertilizer.channel = RELAY_PUMP_FERTILIZER == 0 ? 0 : preferences.getUChar("rFert", RELAY_PUMP_FERTILIZER);
  zones[0].channel = preferences.getUChar("rZ1", RELAY_ZONE_1);
  zones[1].channel = preferences.getUChar("rZ2", RELAY_ZONE_2);
  zones[2].channel = preferences.getUChar("rZ3", RELAY_ZONE_3);
  zones[3].channel = preferences.getUChar("rZ4", RELAY_ZONE_4);
}

void migrateNpkRegisterMap() {
  if (node4NReg == 0 && node4PReg == 1 && node4KReg == 2) {
    node4NReg = NODE4_N_REG;
    node4PReg = NODE4_P_REG;
    node4KReg = NODE4_K_REG;
    preferences.putUShort("n4N", node4NReg);
    preferences.putUShort("n4P", node4PReg);
    preferences.putUShort("n4K", node4KReg);
    Serial.println("Migrated NPK registers to 0x001E-0x0020");
  }
}

void migrateOptionalSensorDefaults() {
  if (preferences.getBool("optSensorV1", false)) return;

  // Flow and tank-level sensors are optional. Older firmware enabled their
  // protections by default, which blocked irrigation when they were absent.
  autoFlowProtection = false;
  autoDryRunProtection = false;
  autoWaterLevelProtection = false;
  preferences.putBool("autoFlow", false);
  preferences.putBool("autoDry", false);
  preferences.putBool("autoWater", false);
  preferences.putBool("optSensorV1", true);
  Serial.println("Migrated optional sensor protections to opt-in");
}

// โหลดค่าที่บันทึกใน ESP32 หากไม่มีจะใช้ค่าเริ่มต้นจาก config.h
void loadRuntimeConfig() {
  runtimeWifiSsid = preferences.isKey("wifiSsid") ? preferences.getString("wifiSsid") : String(WIFI_SSID);
  runtimeWifiPassword = preferences.isKey("wifiPass") ? preferences.getString("wifiPass") : String(WIFI_PASSWORD);
#if defined(DEVICE_PROFILE_FB0007)
  // Provision this physical controller without erasing its unrelated saved
  // calibration, relay map, schedules, and automation settings.
  runtimeWifiSsid = WIFI_OVERRIDE_SSID;
  runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
  preferences.putString("wifiSsid", runtimeWifiSsid);
  preferences.putString("wifiPass", runtimeWifiPassword);
  preferences.putBool("wifiFb0007", true);
#elif defined(DEVICE_PROFILE_FB0008)
  // Apply this cabinet's provisioned network once while preserving the rest
  // of its non-volatile controller configuration.
  if (!preferences.getBool("wifiFb0008", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFb0008", true);
  }
#elif defined(DEVICE_PROFILE_FBP0010)
  // Provision FBP-0010 with the network currently used by its setup computer
  // while preserving calibration, relay mapping, and automation settings.
  if (!preferences.getBool("wifiFbp0010", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFbp0010", true);
  }
  // Provision the confirmed 10IOA12 Modbus slave address without clearing
  // unrelated saved controller settings.
  if (!preferences.getBool("relayFbp0010v2", false)) {
    preferences.putUChar("nRelay", RELAY_NODE_ID);
    preferences.putBool("relayFbp0010v2", true);
  }
#elif defined(DEVICE_PROFILE_FBP0011)
  // Provision this cabinet without erasing its calibration, schedules, or
  // other saved controller settings.
  if (!preferences.getBool("wifiFbp0011", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFbp0011", true);
  }
  if (!preferences.getBool("relayFbp0011", false)) {
    preferences.putUChar("nRelay", RELAY_NODE_ID);
    preferences.putBool("relayFbp0011", true);
  }
#elif defined(DEVICE_PROFILE_FBP0012)
  // Provision this cabinet without erasing its calibration, schedules, or
  // other saved controller settings.
  if (!preferences.getBool("wifiFbp0012", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFbp0012", true);
  }
  if (!preferences.getBool("relayFbp0012", false)) {
    preferences.putUChar("nRelay", RELAY_NODE_ID);
    preferences.putBool("relayFbp0012", true);
  }
#elif defined(DEVICE_PROFILE_FBP0013)
  // Provision this cabinet without erasing its calibration, schedules, or
  // other saved controller settings.
  if (!preferences.getBool("wifiFbp0013", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFbp0013", true);
  }
  if (!preferences.getBool("relayFbp0013", false)) {
    preferences.putUChar("nRelay", RELAY_NODE_ID);
    preferences.putBool("relayFbp0013", true);
  }
#else
  if (!preferences.getBool("wifiFix7", false)) {
    runtimeWifiSsid = WIFI_OVERRIDE_SSID;
    runtimeWifiPassword = WIFI_OVERRIDE_PASSWORD;
    preferences.putString("wifiSsid", runtimeWifiSsid);
    preferences.putString("wifiPass", runtimeWifiPassword);
    preferences.putBool("wifiFix7", true);
  }
#endif
  // Correct the previously saved SSID typo without clearing the other controller settings.
  if (runtimeWifiSsid == "Dr_samart_001") {
    runtimeWifiSsid = "Dr_Samart_001";
    preferences.putString("wifiSsid", runtimeWifiSsid);
  }
  relayNodeId = preferences.getUChar("nRelay", RELAY_NODE_ID);
  sensor3In1NodeId = preferences.getUChar("n3in1", SENSOR_3IN1_NODE_ID);
  soil4In1NodeId = preferences.getUChar("nSoil", SOIL_4IN1_NODE_ID);
  npkNodeId = preferences.getUChar("nNpk", NPK_NODE_ID);
  modbusBaudRate = preferences.getUInt("baud", MODBUS_BAUDRATE);
  node2HumidityReg = preferences.getUShort("n2Hum", NODE2_HUMI_REG);
  node2TemperatureReg = preferences.getUShort("n2Temp", NODE2_TEMP_REG);
  node2LuxReg = preferences.getUShort("n2Lux", NODE2_LUX_REG);
  node3SoilReg = preferences.getUShort("n3Soil", NODE3_SOIL_REG);
  node3TemperatureReg = preferences.getUShort("n3Temp", NODE3_TEMP_REG);
  node3EcReg = preferences.getUShort("n3Ec", NODE3_EC_REG);
  node3PhReg = preferences.getUShort("n3Ph", NODE3_PH_REG);
  node4NReg = preferences.getUShort("n4N", NODE4_N_REG);
  node4PReg = preferences.getUShort("n4P", NODE4_P_REG);
  node4KReg = preferences.getUShort("n4K", NODE4_K_REG);
  migrateNpkRegisterMap();
  autoModeEnabled = preferences.getBool("autoOn", false);
  autoMinMoisture = preferences.getFloat("autoMin", 35.0f);
  autoMaxMoisture = preferences.getFloat("autoMax", 75.0f);
  autoMaxRuntimeSeconds = preferences.isKey("autoRunSec")
    ? preferences.getUInt("autoRunSec", 30UL * 60UL)
    : static_cast<uint32_t>(preferences.getUShort("autoRun", 30)) * 60UL;
  autoRainSkip = preferences.getBool("autoRain", true);
  autoFlowProtection = preferences.getBool("autoFlow", false);
  autoDryRunProtection = preferences.getBool("autoDry", false);
  autoWaterLevelProtection = preferences.getBool("autoWater", false);
  autoFailSafeOnSensorLoss = preferences.getBool("autoSafe", true);
  migrateOptionalSensorDefaults();
  autoZoneMask = preferences.getUChar("autoZones", 0x0F);
  autoCooldownMinutes = preferences.getUShort("autoCool", 20);
  autoDailyRuntimeLimitMinutes = preferences.getUShort("autoDaily", 120);
  scheduleCount = preferences.getUChar("schedCount", 0);
  if (scheduleCount > MAX_SCHEDULES) scheduleCount = 0;
  if (preferences.isKey("schedules")) {
    preferences.getBytes("schedules", schedules, sizeof(schedules));
  }
  applyRelayMap();
}

void allOutputsOff() {
  if (irrigationSource == IrrigationSource::Auto && autoCycleStartedAt > 0) {
    autoDailyRuntimeSeconds += (millis() - autoCycleStartedAt) / 1000UL;
    lastAutoStopAt = millis();
  }
  setRelay(pumpWater, false);
  setRelay(pumpFertilizer, false);
  for (auto &zone : zones) {
    setRelay(zone, false);
  }
  irrigationSource = IrrigationSource::None;
  autoCycleStartedAt = 0;
}

// คำสั่งฉุกเฉิน: พยายามปิดโซนทั้งหมดซ้ำตามค่าที่กำหนด
bool emergencyOutputsOff() {
  if (irrigationSource == IrrigationSource::Auto && autoCycleStartedAt > 0) {
    autoDailyRuntimeSeconds += (millis() - autoCycleStartedAt) / 1000UL;
    lastAutoStopAt = millis();
  }

  RelayWriteResult result = sendEmergencyZonesOff();
  pumpWater.enabled = false;
  pumpWater.autoOffAt = 0;
  pumpFertilizer.enabled = false;
  pumpFertilizer.autoOffAt = 0;
  pumpWaterStartedAt = 0;
  for (auto &zone : zones) {
    zone.enabled = false;
    zone.autoOffAt = 0;
  }
  irrigationSource = IrrigationSource::None;
  autoCycleStartedAt = 0;
  return result != RelayWriteResult::Failed;
}

int16_t toSigned16(uint16_t value) {
  return static_cast<int16_t>(value);
}

void noteSensorReadFailure(uint8_t nodeId, uint16_t startReg, uint8_t count, uint8_t errorCode, uint8_t &errorCount, unsigned long elapsed) {
  if (errorCount < 255) {
    errorCount++;
  }
  Serial.printf("[MODBUS] node=%u holding start=0x%04X count=%u failed err=%u errors=%u time=%lums\n",
                nodeId, startReg, count, errorCode, errorCount, elapsed);
}

bool readHoldingWords(uint8_t nodeId, uint16_t startReg, uint8_t count, uint16_t *values, uint8_t &errorCount) {
  uint8_t response[64];
  uint8_t responseLength = 0;
  unsigned long startedAt = millis();
  bool received = rawModbusRead(nodeId, 0x03, startReg, count, response, responseLength);
  unsigned long elapsed = millis() - startedAt;

  if (!received) {
    noteSensorReadFailure(nodeId, startReg, count, ModbusMaster::ku8MBResponseTimedOut, errorCount, elapsed);
    return false;
  }

  if (responseLength < 5) {
    noteSensorReadFailure(nodeId, startReg, count, ModbusMaster::ku8MBInvalidFunction, errorCount, elapsed);
    return false;
  }

  uint16_t receivedCrc = static_cast<uint16_t>(response[responseLength - 2]) |
                         (static_cast<uint16_t>(response[responseLength - 1]) << 8);
  if (modbusCrc(response, responseLength - 2) != receivedCrc) {
    noteSensorReadFailure(nodeId, startReg, count, ModbusMaster::ku8MBInvalidCRC, errorCount, elapsed);
    return false;
  }

  if (response[0] != nodeId) {
    noteSensorReadFailure(nodeId, startReg, count, ModbusMaster::ku8MBInvalidSlaveID, errorCount, elapsed);
    return false;
  }

  if (response[1] == 0x83) {
    uint8_t exceptionCode = responseLength > 2 ? response[2] : ModbusMaster::ku8MBInvalidFunction;
    noteSensorReadFailure(nodeId, startReg, count, exceptionCode, errorCount, elapsed);
    return false;
  }

  if (response[1] != 0x03 || response[2] < count * 2 || responseLength < static_cast<uint8_t>(5 + count * 2)) {
    noteSensorReadFailure(nodeId, startReg, count, ModbusMaster::ku8MBInvalidFunction, errorCount, elapsed);
    return false;
  }

  for (uint8_t i = 0; i < count; i++) {
    values[i] = (static_cast<uint16_t>(response[3 + (i * 2)]) << 8) | response[4 + (i * 2)];
  }

  errorCount = 0;
#if MODBUS_DEBUG
  Serial.printf("[MODBUS] node=%u start=0x%04X count=%u result=0 time=%lums raw=", nodeId, startReg, count, elapsed);
  for (uint8_t i = 0; i < count; i++) {
    Serial.print(values[i]);
    if (i < count - 1) Serial.print(",");
  }
  Serial.println();
#endif
  return true;
}

float regScaled(uint16_t value, float scale) {
  return value / scale;
}

// Common variants of this 7-in-1 probe encode pH as either x10 or x100.
// Select the x100 form only when x10 would exceed the physical pH range.
float decodeSoilPh(uint16_t value) {
  const float tenths = regScaled(value, 10.0f);
  return tenths <= 14.0f ? tenths : regScaled(value, 100.0f);
}

float regSignedScaled(uint16_t value, float scale) {
  return toSigned16(value) / scale;
}

void clearNode2Values() {
  sensors.node2Humidity = NAN;
  sensors.node2Temperature = NAN;
  sensors.lux = NAN;
}

void clearNode3Values() {
  sensors.soilMoisture = NAN;
  sensors.soilTemperature = NAN;
  sensors.ec = NAN;
  sensors.ph = NAN;
  sensors.salinity = NAN;
}

void clearNode4Values() {
  sensors.nitrogen = NAN;
  sensors.phosphorus = NAN;
  sensors.potassium = NAN;
}

// อ่านเซนเซอร์ดิน 7-in-1: ความชื้น อุณหภูมิ EC pH N P K และความเค็ม
void readNode2() {
  uint16_t values[SOIL_7IN1_REGISTER_COUNT];
  if (readHoldingWords(sensor3In1NodeId, SOIL_7IN1_START_REG,
      SOIL_7IN1_REGISTER_COUNT, values, sensors.node2Errors)) {
    const unsigned long readAt = millis();

    // Node 2 is now the single installed soil probe, not the former air probe.
    sensors.node2Online = false;
    sensors.node2LastReadMs = 0;
    clearNode2Values();

    sensors.node3Online = true;
    sensors.node4Online = true;
    sensors.node3Errors = 0;
    sensors.node4Errors = 0;
    sensors.node3LastReadMs = readAt;
    sensors.node4LastReadMs = readAt;
    sensors.soilMoisture = regScaled(values[0], 10.0f);
    sensors.soilTemperature = regSignedScaled(values[1], 10.0f);
    sensors.ec = values[2];
    sensors.ph = decodeSoilPh(values[3]);
    sensors.nitrogen = values[4];
    sensors.phosphorus = values[5];
    sensors.potassium = values[6];
    sensors.salinity = values[7];
    Serial.printf(
        "[MODBUS] node=2 soil7 moisture=%.1f temp=%.1f ec=%.0f ph=%.1f n=%.0f p=%.0f k=%.0f sal=%.0f\n",
        sensors.soilMoisture, sensors.soilTemperature, sensors.ec, sensors.ph,
        sensors.nitrogen, sensors.phosphorus, sensors.potassium, sensors.salinity);
  } else if (sensors.node2Errors >= 3) {
    sensors.node2Online = false;
    clearNode2Values();
    sensors.node3Online = false;
    sensors.node4Online = false;
    sensors.node3Errors = sensors.node2Errors;
    sensors.node4Errors = sensors.node2Errors;
    clearNode3Values();
    clearNode4Values();
  }
}

void readNode3() {
  uint16_t values[4];
  if (readHoldingWords(soil4In1NodeId, node3SoilReg, 4, values, sensors.node3Errors)) {
    sensors.node3Online = true;
    sensors.node3LastReadMs = millis();
    sensors.soilMoisture = regScaled(values[0], 10.0f);
    sensors.soilTemperature = regSignedScaled(values[1], 10.0f);
    sensors.ec = values[2];
    sensors.ph = regScaled(values[3], 10.0f);
    Serial.printf("[MODBUS] node=3 soil moisture=%.1f temp=%.1f ec=%.0f ph=%.1f\n", sensors.soilMoisture, sensors.soilTemperature, sensors.ec, sensors.ph);
  } else if (sensors.node3Errors >= 3) {
    sensors.node3Online = false;
    clearNode3Values();
  }
}

void readNode4() {
  uint16_t values[3];
  if (readHoldingWords(npkNodeId, node4NReg, 3, values, sensors.node4Errors)) {
    sensors.node4Online = true;
    sensors.node4LastReadMs = millis();
    sensors.nitrogen = values[0];
    sensors.phosphorus = values[1];
    sensors.potassium = values[2];
    Serial.printf("[MODBUS] node=4 npk n=%.0f p=%.0f k=%.0f\n", sensors.nitrogen, sensors.phosphorus, sensors.potassium);
  } else if (sensors.node4Errors >= 3) {
    sensors.node4Online = false;
    clearNode4Values();
  }
}

void readSensors() {
  readNode2();
}

void pollSensorsRealtime() {
  if (millis() - lastSensorPollAt < SENSOR_POLL_INTERVAL_MS) {
    return;
  }

  lastSensorPollAt = millis();
  readNode2();
}

void printScanRegisters(ModbusMaster &node, uint8_t count) {
  Serial.print(" regs=");
  for (uint8_t i = 0; i < count; i++) {
    Serial.print(node.getResponseBuffer(i));
    if (i < count - 1) Serial.print(",");
  }
}

uint16_t modbusCrc(const uint8_t *data, uint8_t length) {
  uint16_t crc = 0xFFFF;
  for (uint8_t pos = 0; pos < length; pos++) {
    crc ^= data[pos];
    for (uint8_t i = 0; i < 8; i++) {
      if (crc & 0x0001) {
        crc >>= 1;
        crc ^= 0xA001;
      } else {
        crc >>= 1;
      }
    }
  }
  return crc;
}

bool rawModbusRead(uint8_t id, uint8_t functionCode, uint16_t startReg, uint16_t count, uint8_t *response, uint8_t &responseLength) {
  uint8_t request[8] = {
      id,
      functionCode,
      static_cast<uint8_t>(startReg >> 8),
      static_cast<uint8_t>(startReg & 0xFF),
      static_cast<uint8_t>(count >> 8),
      static_cast<uint8_t>(count & 0xFF),
      0,
      0,
  };
  uint16_t crc = modbusCrc(request, 6);
  request[6] = crc & 0xFF;
  request[7] = crc >> 8;

  while (RS485Serial.available()) RS485Serial.read();
  RS485Serial.write(request, sizeof(request));
  RS485Serial.flush();

  responseLength = 0;
  unsigned long startAt = millis();
  while (millis() - startAt < MODBUS_SENSOR_TIMEOUT_MS && responseLength < 64) {
    if (RS485Serial.available()) {
      response[responseLength++] = RS485Serial.read();
      startAt = millis();
    }
  }

  return responseLength >= 5;
}

void printRawResponse(uint8_t *response, uint8_t responseLength) {
  Serial.print(" raw=");
  for (uint8_t i = 0; i < responseLength; i++) {
    if (response[i] < 16) Serial.print("0");
    Serial.print(response[i], HEX);
    if (i < responseLength - 1) Serial.print(" ");
  }
}

void rawScanOneBaud(uint32_t baudRate) {
  Serial.printf("RAW RS485 scan baud=%lu start\n", baudRate);
  RS485Serial.end();
  delay(100);
  RS485Serial.begin(baudRate, SERIAL_8N1, RS485_RXD, RS485_TXD);
  delay(100);

  const uint16_t starts[] = {0x0000, 0x0001, 0x0006, 0x0012, 0x001E, 0x0100};
  const uint8_t functions[] = {0x03, 0x04};
  uint8_t response[64];
  uint8_t responseLength = 0;
  uint16_t foundCount = 0;

  for (uint16_t id = 1; id <= 247; id++) {
    for (uint8_t functionCode : functions) {
      for (uint16_t startReg : starts) {
        if (rawModbusRead(static_cast<uint8_t>(id), functionCode, startReg, 1, response, responseLength)) {
          Serial.printf("RAW FOUND id=%u baud=%lu func=0x%02X start=0x%04X len=%u", id, baudRate, functionCode, startReg, responseLength);
          printRawResponse(response, responseLength);
          Serial.println();
          foundCount++;
          goto nextId;
        }
      }
    }

  nextId:
    if (id % 25 == 0) Serial.printf("RAW scan baud=%lu progress id=%u found=%u\n", baudRate, id, foundCount);
  }

  Serial.printf("RAW RS485 scan baud=%lu done found=%u\n", baudRate, foundCount);
}

void rawScanTargetFormat(uint32_t baudRate, uint32_t serialConfig, const char *formatName) {
  Serial.printf("RAW target scan baud=%lu format=%s ids=%u,%u,%u\n", baudRate, formatName, sensor3In1NodeId, soil4In1NodeId, npkNodeId);
  RS485Serial.end();
  delay(100);
  RS485Serial.begin(baudRate, serialConfig, RS485_RXD, RS485_TXD);
  delay(100);

  const uint8_t ids[] = {sensor3In1NodeId, soil4In1NodeId, npkNodeId};
  const uint16_t starts[] = {0x0000, 0x0001, 0x0006, 0x0012, 0x001E, 0x0100};
  const uint8_t functions[] = {0x03, 0x04};
  uint8_t response[64];
  uint8_t responseLength = 0;

  for (uint8_t id : ids) {
    bool found = false;
    for (uint8_t functionCode : functions) {
      for (uint16_t startReg : starts) {
        if (rawModbusRead(id, functionCode, startReg, 1, response, responseLength)) {
          Serial.printf("RAW SENSOR id=%u baud=%lu format=%s func=0x%02X start=0x%04X len=%u", id, baudRate, formatName, functionCode, startReg, responseLength);
          printRawResponse(response, responseLength);
          Serial.println();
          found = true;
          goto nextTargetId;
        }
      }
    }

  nextTargetId:
    if (!found) Serial.printf("RAW SENSOR id=%u baud=%lu format=%s no response\n", id, baudRate, formatName);
  }
}

void scanOneModbusBaud(uint32_t baudRate) {
  Serial.printf("RS485 scan baud=%lu start\n", baudRate);
  RS485Serial.end();
  delay(100);
  RS485Serial.begin(baudRate, SERIAL_8N1, RS485_RXD, RS485_TXD);
  delay(100);

  const uint16_t starts[] = {0x0000, 0x0001, 0x0006, 0x0012, 0x001E, 0x0100};
  const uint8_t counts[] = {1, 3, 4, 7};

  for (uint8_t id = 1; id <= 247; id++) {
    scanNode.begin(id, RS485Serial);

    for (uint16_t start : starts) {
      for (uint8_t count : counts) {
        uint8_t result = scanNode.readHoldingRegisters(start, count);
        if (result == scanNode.ku8MBSuccess) {
          Serial.printf("RS485 FOUND id=%u baud=%lu func=holding start=0x%04X count=%u", id, baudRate, start, count);
          printScanRegisters(scanNode, count);
          Serial.println();
          delay(80);
          goto nextId;
        }

        result = scanNode.readInputRegisters(start, count);
        if (result == scanNode.ku8MBSuccess) {
          Serial.printf("RS485 FOUND id=%u baud=%lu func=input start=0x%04X count=%u", id, baudRate, start, count);
          printScanRegisters(scanNode, count);
          Serial.println();
          delay(80);
          goto nextId;
        }
      }
    }

  nextId:
    delay(20);
  }

  Serial.printf("RS485 scan baud=%lu done\n", baudRate);
}

void scanTargetSensorBaud(uint32_t baudRate) {
  Serial.printf("RS485 target diagnostic baud=%lu ids=%u,%u,%u\n", baudRate, sensor3In1NodeId, soil4In1NodeId, npkNodeId);
  RS485Serial.end();
  delay(100);
  RS485Serial.begin(baudRate, SERIAL_8N1, RS485_RXD, RS485_TXD);
  delay(100);

  uint8_t ids[] = {sensor3In1NodeId, soil4In1NodeId, npkNodeId};
  for (uint8_t id : ids) {
    scanNode.begin(id, RS485Serial);
    uint8_t result = scanNode.readHoldingRegisters(0x0000, 7);
    if (result == scanNode.ku8MBSuccess) {
      Serial.printf("RS485 SENSOR id=%u func=holding start=0x0000 count=7", id);
      printScanRegisters(scanNode, 7);
      Serial.println();
      continue;
    }
    Serial.printf("RS485 id=%u holding result=%u\n", id, result);

    result = scanNode.readInputRegisters(0x0000, 7);
    if (result == scanNode.ku8MBSuccess) {
      Serial.printf("RS485 SENSOR id=%u func=input start=0x0000 count=7", id);
      printScanRegisters(scanNode, 7);
      Serial.println();
      continue;
    }
    Serial.printf("RS485 id=%u input result=%u\n", id, result);
  }
}

void scanModbusBus() {
  rawScanTargetFormat(9600, SERIAL_8N1, "8N1");
  rawScanTargetFormat(9600, SERIAL_8E1, "8E1");
  rawScanTargetFormat(9600, SERIAL_8O1, "8O1");
  rawScanTargetFormat(4800, SERIAL_8N1, "8N1");
  rawScanTargetFormat(4800, SERIAL_8E1, "8E1");
  rawScanTargetFormat(2400, SERIAL_8N1, "8N1");
  rawScanTargetFormat(19200, SERIAL_8N1, "8N1");
  scanTargetSensorBaud(9600);
  scanTargetSensorBaud(4800);
  scanTargetSensorBaud(2400);
  setupModbus();
}

void scanRelayReadOnly() {
  const uint32_t baudRates[] = {9600, 4800, 19200, 2400, 38400, 57600, 115200, 1200};
  const uint32_t serialConfigs[] = {SERIAL_8N1, SERIAL_8O1, SERIAL_8E1};
  const char *formatNames[] = {"8N1", "8O1", "8E1"};
  uint8_t response[64];
  uint8_t responseLength = 0;

  Serial.println("RS485 10IOA12 product-ID scan start");
  for (uint32_t baudRate : baudRates) {
    for (uint8_t formatIndex = 0; formatIndex < 3; formatIndex++) {
      RS485Serial.end();
      delay(100);
      RS485Serial.begin(baudRate, serialConfigs[formatIndex], RS485_RXD, RS485_TXD);
      delay(100);
      Serial.printf("RS485 10IOA12 scan baud=%lu format=%s\n", baudRate, formatNames[formatIndex]);
      for (uint8_t id = 1; id <= 63; id++) {
        if (!rawModbusRead(id, 0x03, 0x00F7, 1, response, responseLength)) continue;
        if (responseLength != 7 || response[0] != id || response[1] != 0x03 || response[2] != 0x02) continue;
        uint16_t receivedCrc = response[5] | (static_cast<uint16_t>(response[6]) << 8);
        if (modbusCrc(response, 5) != receivedCrc) continue;
        uint16_t productId = (static_cast<uint16_t>(response[3]) << 8) | response[4];
        if (productId != 1012) continue;
        Serial.printf("RS485 10IOA12 FOUND id=%u baud=%lu format=%s product=%u\n", id, baudRate, formatNames[formatIndex], productId);
        setupModbus();
        return;
      }
    }
  }
  Serial.println("RS485 10IOA12 not found");
  setupModbus();
}

void addNumberOrNull(JsonObject object, const char *key, float value) {
  if (isnan(value)) {
    object[key] = nullptr;
  } else {
    object[key] = value;
  }
}

void publishStatus(bool online) {
  JsonDocument doc;
  doc["online"] = online;
  doc["wifiSsid"] = WiFi.isConnected() ? WiFi.SSID() : "";
  JsonObject network = doc["network"].to<JsonObject>();
  network["rssi"] = WiFi.isConnected() ? WiFi.RSSI() : 0;
  network["ip"] = WiFi.isConnected() ? WiFi.localIP().toString() : "";
  network["wifiConnectAttempts"] = wifiConnectAttempts;
  network["mqttConnectAttempts"] = mqttConnectAttempts;
  network["wifiDisconnectCount"] = wifiDisconnectCount;
  network["mqttDisconnectCount"] = mqttDisconnectCount;
  network["freeHeap"] = ESP.getFreeHeap();
  network["uptimeSeconds"] = millis() / 1000UL;
  doc["lastUpdated"] = timestampText();
  publishJson(statusTopic, doc, true);
}

// รวมค่าเซนเซอร์และสถานะระบบ แล้วส่งให้ Dashboard ผ่าน MQTT
void publishTelemetry() {
  JsonDocument doc;
  doc["online"] = WiFi.isConnected() && mqtt.connected();
  doc["wifiSsid"] = WiFi.isConnected() ? WiFi.SSID() : "";
  doc["pumpWater"] = pumpWater.enabled;
  doc["pumpFertilizer"] = pumpFertilizer.enabled;
  doc["relayFeedbackAvailable"] = relayFeedbackAvailable;
  doc["relayStateSource"] = relayFeedbackAvailable ? "readback" : "commanded";
  JsonObject timers = doc["autoOffRemainingSeconds"].to<JsonObject>();
  timers["pumpWater"] = autoOffRemainingSeconds(pumpWater);
  timers["pumpFertilizer"] = autoOffRemainingSeconds(pumpFertilizer);
  JsonObject zoneTimers = timers["zones"].to<JsonObject>();
  for (int i = 0; i < 4; i++) {
    zoneTimers[String(i + 1)] = autoOffRemainingSeconds(zones[i]);
  }
  JsonObject network = doc["network"].to<JsonObject>();
  network["rssi"] = WiFi.isConnected() ? WiFi.RSSI() : 0;
  network["ip"] = WiFi.isConnected() ? WiFi.localIP().toString() : "";
  network["wifiConnectAttempts"] = wifiConnectAttempts;
  network["mqttConnectAttempts"] = mqttConnectAttempts;
  network["wifiDisconnectCount"] = wifiDisconnectCount;
  network["mqttDisconnectCount"] = mqttDisconnectCount;
  network["freeHeap"] = ESP.getFreeHeap();
  network["uptimeSeconds"] = millis() / 1000UL;

  JsonObject zoneObject = doc["zones"].to<JsonObject>();
  for (int i = 0; i < 4; i++) {
    zoneObject[String(i + 1)] = zones[i].enabled;
  }

  JsonObject sensorObject = doc["sensors"].to<JsonObject>();
  const bool airValid = sensors.node2Online && !isnan(sensors.node2Humidity) && !isnan(sensors.node2Temperature) && !isnan(sensors.lux);
  const bool soilValid = sensors.node3Online && !isnan(sensors.soilMoisture) && !isnan(sensors.soilTemperature) && !isnan(sensors.ec) && !isnan(sensors.ph) && !isnan(sensors.salinity);
  const bool npkValid = sensors.node4Online && !isnan(sensors.nitrogen) && !isnan(sensors.phosphorus) && !isnan(sensors.potassium);
  sensorObject["airOnline"] = sensors.node2Online;
  sensorObject["soilOnline"] = sensors.node3Online;
  sensorObject["npkOnline"] = sensors.node4Online;
  sensorObject["airValid"] = airValid;
  sensorObject["soilValid"] = soilValid;
  sensorObject["npkValid"] = npkValid;
  sensorObject["airErrorCount"] = 0;
  sensorObject["soilErrorCount"] = sensors.node3Errors;
  sensorObject["npkErrorCount"] = sensors.node4Errors;
  sensorObject["airLastReadMs"] = sensors.node2LastReadMs;
  sensorObject["soilLastReadMs"] = sensors.node3LastReadMs;
  sensorObject["npkLastReadMs"] = sensors.node4LastReadMs;
  addNumberOrNull(sensorObject, "humidity", sensors.node2Humidity);
  addNumberOrNull(sensorObject, "temperature", !isnan(sensors.soilTemperature) ? sensors.soilTemperature : sensors.node2Temperature);
  addNumberOrNull(sensorObject, "lux", sensors.lux);
  addNumberOrNull(sensorObject, "soilMoisture", sensors.soilMoisture);
  addNumberOrNull(sensorObject, "ec", sensors.ec);
  addNumberOrNull(sensorObject, "ph", sensors.ph);
  addNumberOrNull(sensorObject, "salinity", sensors.salinity);
  addNumberOrNull(sensorObject, "nitrogen", sensors.nitrogen);
  addNumberOrNull(sensorObject, "phosphorus", sensors.phosphorus);
  addNumberOrNull(sensorObject, "potassium", sensors.potassium);
  addNumberOrNull(sensorObject, "flowRate", flowRate);
  addNumberOrNull(sensorObject, "waterLevel", waterLevel);
  sensorObject["rain"] = rainDetected;

  JsonObject airObject = sensorObject["air"].to<JsonObject>();
  airObject["online"] = sensors.node2Online;
  airObject["valid"] = airValid;
  airObject["errors"] = 0;
  addNumberOrNull(airObject, "humidity", sensors.node2Humidity);
  addNumberOrNull(airObject, "temperature", sensors.node2Temperature);
  addNumberOrNull(airObject, "lux", sensors.lux);

  JsonObject soilObject = sensorObject["soil"].to<JsonObject>();
  soilObject["online"] = sensors.node3Online;
  soilObject["valid"] = soilValid;
  soilObject["errors"] = sensors.node3Errors;
  addNumberOrNull(soilObject, "moisture", sensors.soilMoisture);
  addNumberOrNull(soilObject, "temperature", sensors.soilTemperature);
  addNumberOrNull(soilObject, "ec", sensors.ec);
  addNumberOrNull(soilObject, "ph", sensors.ph);
  addNumberOrNull(soilObject, "salinity", sensors.salinity);

  JsonObject npkObject = sensorObject["npk"].to<JsonObject>();
  npkObject["online"] = sensors.node4Online;
  npkObject["valid"] = npkValid;
  npkObject["errors"] = sensors.node4Errors;
  addNumberOrNull(npkObject, "nitrogen", sensors.nitrogen);
  addNumberOrNull(npkObject, "phosphorus", sensors.phosphorus);
  addNumberOrNull(npkObject, "potassium", sensors.potassium);

  doc["lastUpdated"] = timestampText();
  publishJson(telemetryTopic, doc);
}

// แปลคำสั่ง JSON จากเว็บ เช่น เปิด/ปิดโซน ตาราง และโหมดอัตโนมัติ
bool handleCommand(JsonDocument &doc, String &resultMessage) {
  lastCommandHadUnconfirmedRelayWrite = false;
  const char *type = doc["type"] | "";
  bool enabled = doc["enabled"] | false;
  unsigned long autoOffSeconds = doc["autoOffSeconds"] | 0;
  const unsigned long maxManualRuntimeSeconds = 6UL * 60UL * 60UL;

  if (strlen(type) == 0) {
    resultMessage = "Command type is required";
    return false;
  }

  bool timedOutputCommand = strcmp(type, "pump_water") == 0
      || strcmp(type, "pump_fertilizer") == 0
      || strcmp(type, "zone") == 0
      || strcmp(type, "relay") == 0;
  if (enabled && timedOutputCommand && (autoOffSeconds < 10 || autoOffSeconds > maxManualRuntimeSeconds)) {
    resultMessage = "Invalid or missing auto-off duration";
    return false;
  }

  if (strcmp(type, "emergency_stop") == 0) {
    if (!emergencyOutputsOff()) {
      resultMessage = "Emergency OFF command could not be transmitted";
      return false;
    }
    publishAlarm("emergency_stop", "Emergency stop activated", "critical");
  } else if (strcmp(type, "pump_water") == 0) {
    if (enabled && !canStartIrrigation("manual pump command")) {
      resultMessage = "Irrigation safety conditions rejected the command";
      return false;
    }
    if (enabled && !anyZoneEnabled()) {
      resultMessage = "Open an irrigation zone before starting the water pump";
      return false;
    }
    if (!enabled && pumpFertilizer.enabled && !setRelay(pumpFertilizer, false)) {
      resultMessage = "Could not stop the fertilizer pump before the water pump";
      return false;
    }
    if (!setRelay(pumpWater, enabled, autoOffSeconds)) {
      resultMessage = "Relay board did not confirm the water pump command";
      return false;
    }
  } else if (strcmp(type, "pump_fertilizer") == 0) {
    if (enabled && (!pumpWater.enabled || !anyZoneEnabled())) {
      resultMessage = "Fertilizer pump requires an active water pump and irrigation zone";
      return false;
    }
    if (!setRelay(pumpFertilizer, enabled, autoOffSeconds)) {
      resultMessage = "Relay board did not confirm the fertilizer pump command";
      return false;
    }
  } else if (strcmp(type, "zone") == 0) {
    int zone = doc["zone"] | 0;
    if (zone < 1 || zone > 4) {
      resultMessage = "Invalid irrigation zone";
      return false;
    }
    if (enabled) {
      if (!startWaterOutput(zones[zone - 1], autoOffSeconds, "manual zone command")) {
        resultMessage = "Irrigation safety conditions rejected the command";
        return false;
      }
    } else {
      if (!stopZoneAndMaybePump(static_cast<uint8_t>(zone - 1))) {
        resultMessage = "Could not safely stop the irrigation path";
        return false;
      }
    }
  } else if (strcmp(type, "relay") == 0) {
    int channel = doc["channel"] | 0;
    if (channel < 1 || channel > 12) {
      resultMessage = "Invalid relay channel";
      return false;
    }
    RelayOutput output = {"manualRelay", static_cast<uint8_t>(channel), false, 0};
    if (!setRelay(output, enabled, autoOffSeconds)) {
      resultMessage = "Relay board did not confirm the channel command";
      return false;
    }
  } else if (strcmp(type, "auto_mode") == 0) {
    float nextMin = doc["minMoisture"] | autoMinMoisture;
    float nextMax = doc["maxMoisture"] | autoMaxMoisture;
    uint32_t nextRuntimeSeconds = doc["maxRuntimePerZoneSeconds"].isNull()
      ? static_cast<uint32_t>(doc["maxRuntimePerZone"] | max(1UL, autoMaxRuntimeSeconds / 60UL)) * 60UL
      : doc["maxRuntimePerZoneSeconds"].as<uint32_t>();
    uint16_t nextCooldown = doc["cooldownMinutes"] | autoCooldownMinutes;
    uint16_t nextDailyLimit = doc["dailyRuntimeLimitMinutes"] | autoDailyRuntimeLimitMinutes;
    JsonArray zoneIds = doc["zoneIds"].as<JsonArray>();
    uint8_t nextZoneMask = 0;
    for (JsonVariant zoneValue : zoneIds) {
      int zone = zoneValue.as<int>();
      if (zone >= 1 && zone <= 4) nextZoneMask |= 1 << (zone - 1);
    }
    if (nextMin < 0 || nextMin > 95 || nextMax < 5 || nextMax > 100 || nextMax - nextMin < 5) {
      resultMessage = "Invalid moisture thresholds";
      return false;
    }
    if (nextRuntimeSeconds < 1 || nextRuntimeSeconds > 7200 || nextCooldown < 1 || nextCooldown > 240 || nextDailyLimit < (nextRuntimeSeconds + 59) / 60 || nextDailyLimit > 720) {
      resultMessage = "Invalid automatic runtime limits";
      return false;
    }
    if (nextZoneMask == 0) {
      resultMessage = "At least one irrigation zone is required";
      return false;
    }
    bool nextWaterProtection = doc["waterLevelProtection"] | autoWaterLevelProtection;
    bool nextFlowProtection = doc["flowProtection"] | autoFlowProtection;
    bool nextDryRunProtection = doc["dryRunProtection"] | autoDryRunProtection;
    bool nextFailSafe = doc["failSafeOnSensorLoss"] | autoFailSafeOnSensorLoss;
    if (enabled && isnan(sensors.soilMoisture)) {
      resultMessage = "Soil moisture sensor is unavailable";
      return false;
    }
    if (enabled && nextFailSafe && nextWaterProtection && !hasNumber(waterLevel)) {
      resultMessage = "Water level sensor is unavailable";
      return false;
    }
    if (enabled && nextFailSafe && (nextFlowProtection || nextDryRunProtection) && !hasNumber(flowRate)) {
      resultMessage = "Flow sensor is unavailable";
      return false;
    }
    if (!enabled && irrigationSource == IrrigationSource::Auto) allOutputsOff();
    autoModeEnabled = enabled;
    autoMinMoisture = nextMin;
    autoMaxMoisture = nextMax;
    autoMaxRuntimeSeconds = nextRuntimeSeconds;
    autoCooldownMinutes = nextCooldown;
    autoDailyRuntimeLimitMinutes = nextDailyLimit;
    autoZoneMask = nextZoneMask;
    autoRainSkip = doc["rainSkip"] | autoRainSkip;
    autoFlowProtection = nextFlowProtection;
    autoDryRunProtection = nextDryRunProtection;
    autoWaterLevelProtection = nextWaterProtection;
    autoFailSafeOnSensorLoss = nextFailSafe;
    preferences.putBool("autoOn", autoModeEnabled);
    preferences.putFloat("autoMin", autoMinMoisture);
    preferences.putFloat("autoMax", autoMaxMoisture);
    preferences.putUInt("autoRunSec", autoMaxRuntimeSeconds);
    preferences.putBool("autoRain", autoRainSkip);
    preferences.putBool("autoFlow", autoFlowProtection);
    preferences.putBool("autoDry", autoDryRunProtection);
    preferences.putBool("autoWater", autoWaterLevelProtection);
    preferences.putBool("autoSafe", autoFailSafeOnSensorLoss);
    preferences.putUChar("autoZones", autoZoneMask);
    preferences.putUShort("autoCool", autoCooldownMinutes);
    preferences.putUShort("autoDaily", autoDailyRuntimeLimitMinutes);
    Serial.printf("Auto mode: %s min=%.1f max=%.1f runtime=%lu sec\n", autoModeEnabled ? "ON" : "OFF", autoMinMoisture, autoMaxMoisture, static_cast<unsigned long>(autoMaxRuntimeSeconds));
  } else if (strcmp(type, "config") == 0) {
    JsonObject settings = doc["settings"];
    JsonObject sensorCapabilities = settings["sensorCapabilities"];
    JsonObject hardware = settings["hardware"];
    JsonObject modbus = hardware["modbus"];
    JsonObject relayMap = hardware["relayMap"];
    JsonObject registers = hardware["registers"];

    const char *nextWifiSsid = settings["wifiSsid"] | nullptr;
    const char *nextWifiPassword = settings["wifiPassword"] | nullptr;
    bool wifiChanged = false;

    if (nextWifiSsid != nullptr && (strlen(nextWifiSsid) == 0 || strlen(nextWifiSsid) > 32)) {
      resultMessage = "Invalid WiFi SSID";
      return false;
    }
    if (nextWifiPassword != nullptr && (strlen(nextWifiPassword) < 8 || strlen(nextWifiPassword) > 63)) {
      resultMessage = "Invalid WiFi password";
      return false;
    }

    int nextNodeIds[] = {
      modbus["relayNodeId"] | relayNodeId,
      modbus["sensor3In1NodeId"] | sensor3In1NodeId,
      modbus["soil4In1NodeId"] | soil4In1NodeId,
      modbus["npkNodeId"] | npkNodeId,
    };
    for (uint8_t i = 0; i < 4; i++) {
      if (nextNodeIds[i] < 1 || nextNodeIds[i] > 247) {
        resultMessage = "Invalid Modbus node ID";
        return false;
      }
    }

    int nextRelayChannels[] = {
      relayMap["pumpWater"] | pumpWater.channel,
      relayMap["pumpFertilizer"] | pumpFertilizer.channel,
      relayMap["zone1"] | zones[0].channel,
      relayMap["zone2"] | zones[1].channel,
      relayMap["zone3"] | zones[2].channel,
      relayMap["zone4"] | zones[3].channel,
    };
    for (uint8_t i = 0; i < 6; i++) {
      const bool optionalPumpChannel = i < 2;
      if (nextRelayChannels[i] > 12 || (!optionalPumpChannel && nextRelayChannels[i] < 1)
          || (optionalPumpChannel && nextRelayChannels[i] < 0)) {
        resultMessage = "Invalid relay mapping";
        return false;
      }
      for (uint8_t j = i + 1; j < 6; j++) {
        if (nextRelayChannels[i] > 0 && nextRelayChannels[i] == nextRelayChannels[j]) {
          resultMessage = "Relay mappings must be unique";
          return false;
        }
      }
    }

    uint32_t nextBaudRate = modbus["baudRate"] | modbusBaudRate;
    if (nextBaudRate != 1200 && nextBaudRate != 2400 && nextBaudRate != 4800
        && nextBaudRate != 9600 && nextBaudRate != 19200 && nextBaudRate != 38400
        && nextBaudRate != 57600 && nextBaudRate != 115200) {
      resultMessage = "Unsupported Modbus baud rate";
      return false;
    }

    const char *registerKeys[] = {
      "node2Humidity", "node2Temperature", "node2Lux", "node3Soil", "node3Temperature",
      "node3Ec", "node3Ph", "node4N", "node4P", "node4K"
    };
    for (const char *key : registerKeys) {
      if (!registers[key].isNull()) {
        long value = registers[key].as<long>();
        if (value < 0 || value > 65535) {
          resultMessage = "Invalid Modbus register address";
          return false;
        }
      }
    }

    // A disabled optional sensor must never leave its dependent protection
    // enabled in NVS, even if a later auto_mode message is missed.
    JsonVariant flowSensor = sensorCapabilities["flowSensor"];
    if (!flowSensor.isNull() && !flowSensor.as<bool>()) {
      autoFlowProtection = false;
      autoDryRunProtection = false;
      preferences.putBool("autoFlow", false);
      preferences.putBool("autoDry", false);
    }
    JsonVariant waterLevelSensor = sensorCapabilities["waterLevelSensor"];
    if (!waterLevelSensor.isNull() && !waterLevelSensor.as<bool>()) {
      autoWaterLevelProtection = false;
      preferences.putBool("autoWater", false);
    }

    if (nextWifiSsid != nullptr && strlen(nextWifiSsid) > 0 && strlen(nextWifiSsid) <= 32) {
      String ssidValue = String(nextWifiSsid);
      if (ssidValue != runtimeWifiSsid) {
        runtimeWifiSsid = ssidValue;
        preferences.putString("wifiSsid", runtimeWifiSsid);
        wifiChanged = true;
      }
    }

    if (nextWifiPassword != nullptr && strlen(nextWifiPassword) <= 63 && (strlen(nextWifiPassword) == 0 || strlen(nextWifiPassword) >= 8)) {
      String passwordValue = String(nextWifiPassword);
      if (passwordValue != runtimeWifiPassword) {
        runtimeWifiPassword = passwordValue;
        preferences.putString("wifiPass", runtimeWifiPassword);
        wifiChanged = true;
      }
    }

    relayNodeId = modbus["relayNodeId"] | relayNodeId;
    sensor3In1NodeId = modbus["sensor3In1NodeId"] | sensor3In1NodeId;
    soil4In1NodeId = modbus["soil4In1NodeId"] | soil4In1NodeId;
    npkNodeId = modbus["npkNodeId"] | npkNodeId;
    modbusBaudRate = modbus["baudRate"] | modbusBaudRate;

    preferences.putUChar("nRelay", relayNodeId);
    preferences.putUChar("n3in1", sensor3In1NodeId);
    preferences.putUChar("nSoil", soil4In1NodeId);
    preferences.putUChar("nNpk", npkNodeId);
    preferences.putUInt("baud", modbusBaudRate);

    preferences.putUChar("rPump", relayMap["pumpWater"] | pumpWater.channel);
    preferences.putUChar("rFert", relayMap["pumpFertilizer"] | pumpFertilizer.channel);
    preferences.putUChar("rZ1", relayMap["zone1"] | zones[0].channel);
    preferences.putUChar("rZ2", relayMap["zone2"] | zones[1].channel);
    preferences.putUChar("rZ3", relayMap["zone3"] | zones[2].channel);
    preferences.putUChar("rZ4", relayMap["zone4"] | zones[3].channel);

    node2HumidityReg = registers["node2Humidity"] | node2HumidityReg;
    node2TemperatureReg = registers["node2Temperature"] | node2TemperatureReg;
    node2LuxReg = registers["node2Lux"] | node2LuxReg;
    node3SoilReg = registers["node3Soil"] | node3SoilReg;
    node3TemperatureReg = registers["node3Temperature"] | node3TemperatureReg;
    node3EcReg = registers["node3Ec"] | node3EcReg;
    node3PhReg = registers["node3Ph"] | node3PhReg;
    node4NReg = registers["node4N"] | node4NReg;
    node4PReg = registers["node4P"] | node4PReg;
    node4KReg = registers["node4K"] | node4KReg;
    migrateNpkRegisterMap();

    preferences.putUShort("n2Hum", node2HumidityReg);
    preferences.putUShort("n2Temp", node2TemperatureReg);
    preferences.putUShort("n2Lux", node2LuxReg);
    preferences.putUShort("n3Soil", node3SoilReg);
    preferences.putUShort("n3Temp", node3TemperatureReg);
    preferences.putUShort("n3Ec", node3EcReg);
    preferences.putUShort("n3Ph", node3PhReg);
    preferences.putUShort("n4N", node4NReg);
    preferences.putUShort("n4P", node4PReg);
    preferences.putUShort("n4K", node4KReg);
    applyRelayMap();
    setupModbus();
    if (wifiChanged) {
      wifiReconnectRequested = true;
      Serial.printf("WiFi config saved: %s\n", runtimeWifiSsid.c_str());
    }
    Serial.println("Hardware config saved and applied");
  } else if (strcmp(type, "schedule_sync") == 0) {
    JsonArray items = doc["schedules"].as<JsonArray>();
    if (items.isNull() || items.size() > MAX_SCHEDULES) {
      resultMessage = "Invalid schedule list";
      return false;
    }
    for (JsonObject item : items) {
      const char *startTime = item["startTime"] | "";
      int zone = item["zone"] | 0;
      int duration = item["durationMinutes"] | 0;
      bool validTime = strlen(startTime) == 5
          && startTime[2] == ':'
          && isDigit(startTime[0]) && isDigit(startTime[1])
          && isDigit(startTime[3]) && isDigit(startTime[4]);
      int hour = validTime ? (startTime[0] - '0') * 10 + (startTime[1] - '0') : -1;
      int minute = validTime ? (startTime[3] - '0') * 10 + (startTime[4] - '0') : -1;
      JsonArray days = item["days"].as<JsonArray>();
      if (!validTime || hour > 23 || minute > 59 || zone < 1 || zone > 4
          || duration < 1 || duration > 240 || days.isNull() || days.size() == 0) {
        resultMessage = "Invalid schedule entry";
        return false;
      }
    }

    scheduleCount = items.size();
    for (uint8_t i = 0; i < scheduleCount; i++) {
      JsonObject item = items[i];
      const char *startTime = item["startTime"] | "00:00";
      int hour = atoi(startTime);
      const char *colon = strchr(startTime, ':');
      int minute = colon ? atoi(colon + 1) : 0;
      schedules[i].enabled = item["enabled"] | false;
      schedules[i].zone = item["zone"] | 1;
      schedules[i].durationMinutes = item["durationMinutes"] | 1;
      schedules[i].startMinute = constrain(hour, 0, 23) * 60 + constrain(minute, 0, 59);
      schedules[i].daysMask = 0;
      for (JsonVariant day : item["days"].as<JsonArray>()) {
        String value = day.as<String>();
        if (value == "Sun") schedules[i].daysMask |= 1 << 0;
        if (value == "Mon") schedules[i].daysMask |= 1 << 1;
        if (value == "Tue") schedules[i].daysMask |= 1 << 2;
        if (value == "Wed") schedules[i].daysMask |= 1 << 3;
        if (value == "Thu") schedules[i].daysMask |= 1 << 4;
        if (value == "Fri") schedules[i].daysMask |= 1 << 5;
        if (value == "Sat") schedules[i].daysMask |= 1 << 6;
      }
      schedules[i].running = false;
    }
    preferences.putBytes("schedules", schedules, sizeof(schedules));
    preferences.putUChar("schedCount", scheduleCount);
    Serial.printf("Schedules synced: %u\n", scheduleCount);
  } else {
    resultMessage = "Unsupported command type";
    return false;
  }

  publishTelemetry();
  resultMessage = lastCommandHadUnconfirmedRelayWrite
    ? "Command transmitted; relay feedback unavailable"
    : "Command confirmed and applied";
  return true;
}

// ถูกเรียกอัตโนมัติเมื่อ ESP32 ได้รับข้อความ MQTT
void mqttCallback(char *topic, byte *payload, unsigned int length) {
  Serial.printf("MQTT message on %s\n", topic);
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, payload, length);

  if (error) {
    Serial.printf("JSON parse failed: %s\n", error.c_str());
    return;
  }

  const char *commandId = doc["commandId"] | "";
  if (publishCachedCommandAck(commandId)) {
    Serial.printf("Duplicate command %s acknowledged without reapplying\n", commandId);
    return;
  }
  String resultMessage;
  bool ok = handleCommand(doc, resultMessage);
  const char *ackStatus = !ok ? "error" : lastCommandHadUnconfirmedRelayWrite ? "unconfirmed" : "ok";
  publishCommandAck(commandId, ackStatus, resultMessage.c_str());
  rememberCommandAck(commandId, ackStatus, resultMessage);
}

// เชื่อมต่อ Wi-Fi และเว้นระยะก่อนลองใหม่เมื่อเชื่อมต่อไม่สำเร็จ
void connectWiFi() {
  if (WiFi.isConnected()) {
    if (!wifiWasConnected) {
      wifiWasConnected = true;
      wifiAttemptInProgress = false;
      wifiFailureStreak = 0;
      nextWifiReconnectAt = 0;
      Serial.printf("WiFi connected: %s, RSSI=%d dBm\n",
                    WiFi.localIP().toString().c_str(), WiFi.RSSI());
      configureMqttServer();
    }
    return;
  }

  if (wifiWasConnected) {
    wifiWasConnected = false;
    wifiDisconnectCount++;
    mqtt.disconnect();
    mqttNetworkClient.stop();
    mqttWasConnected = false;
    nextMqttReconnectAt = 0;
    Serial.printf("WiFi connection lost, status=%d, disconnects=%lu\n",
                  WiFi.status(), static_cast<unsigned long>(wifiDisconnectCount));
  }

  if (runtimeWifiSsid.isEmpty()) {
    Serial.println("WiFi SSID is empty");
    return;
  }

  if (wifiAttemptInProgress) {
    if (millis() - wifiAttemptStartedAt < WIFI_CONNECT_TIMEOUT_MS) return;

    wifiAttemptInProgress = false;
    wifiFailureStreak++;
    WiFi.disconnect(false, false);
    nextWifiReconnectAt = millis() + reconnectDelay(
        WIFI_RECONNECT_MIN_MS, WIFI_RECONNECT_MAX_MS, wifiFailureStreak);
    Serial.printf("WiFi attempt timed out, status=%d, retry in %lums\n",
                  WiFi.status(), nextWifiReconnectAt - millis());
    return;
  }

  if (!timeReached(nextWifiReconnectAt)) return;

  wifiConnectAttempts++;
  wifiAttemptStartedAt = millis();
  wifiAttemptInProgress = true;
  Serial.printf("Starting WiFi attempt %lu: %s\n",
                static_cast<unsigned long>(wifiConnectAttempts), runtimeWifiSsid.c_str());
  WiFi.mode(WIFI_STA);
  WiFi.begin(runtimeWifiSsid.c_str(), runtimeWifiPassword.c_str());
}

// เชื่อมต่อ MQTT ประกาศ online และสมัครรับ topic คำสั่งของตู้
void connectMqtt() {
  if (!WiFi.isConnected()) return;

  if (mqtt.connected()) {
    if (!mqttWasConnected) {
      mqttWasConnected = true;
      mqttFailureStreak = 0;
      nextMqttReconnectAt = 0;
    }
    return;
  }

  if (mqttWasConnected) {
    mqttWasConnected = false;
    mqttDisconnectCount++;
    Serial.printf("MQTT connection lost, rc=%d, disconnects=%lu\n",
                  mqtt.state(), static_cast<unsigned long>(mqttDisconnectCount));
  }

  if (!timeReached(nextMqttReconnectAt)) return;

  String brokerHost = String(MQTT_HOST);
  brokerHost.toLowerCase();
  bool publicBroker = brokerHost == "broker.hivemq.com" || brokerHost == "test.mosquitto.org";
  bool allowedPublicBroker = MQTT_ALLOW_PUBLIC_BROKER
      && MQTT_PORT == 1883;
  bool secureConfiguration = MQTT_PORT == 8883
      && strlen(MQTT_USERNAME) > 0
      && strlen(MQTT_PASSWORD) > 0
      && strlen(MQTT_ROOT_CA) > 0
      && !publicBroker;
  if (!secureConfiguration && !allowedPublicBroker) {
    static bool securityErrorLogged = false;
    if (!securityErrorLogged) {
      securityErrorLogged = true;
      Serial.println("MQTT blocked: configure a private TLS broker, device-scoped credentials, and a trusted root CA");
    }
    return;
  }

  // Certificate validation needs a sane clock. Avoid repeatedly opening a TLS
  // socket while SNTP is still synchronizing after WiFi reconnects.
  if (!allowedPublicBroker && time(nullptr) < 1700000000) {
    static unsigned long lastClockWaitLogAt = 0;
    if (lastClockWaitLogAt == 0 || millis() - lastClockWaitLogAt >= 10000UL) {
      lastClockWaitLogAt = millis();
      Serial.println("MQTT waiting for SNTP time before TLS handshake");
    }
    nextMqttReconnectAt = millis() + 1000UL;
    return;
  }

  String clientId = String("smart-farm-") + DEVICE_ID + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  const char *offlineWill = "{\"online\":false,\"reason\":\"connection_lost\"}";

  mqttConnectAttempts++;
  mqttNetworkClient.stop();
  Serial.printf("Connecting MQTT attempt %lu: %s:%d\n",
                static_cast<unsigned long>(mqttConnectAttempts), MQTT_HOST, MQTT_PORT);
  bool connected = mqtt.connect(
      clientId.c_str(),
      MQTT_USERNAME,
      MQTT_PASSWORD,
      statusTopic.c_str(),
      1,
      true,
      offlineWill,
      true);

  if (connected) {
    mqttWasConnected = true;
    mqttFailureStreak = 0;
    nextMqttReconnectAt = 0;
    Serial.println("MQTT connected");
    if (!mqtt.subscribe(commandTopic.c_str(), 1)) {
      Serial.println("MQTT command subscription failed; reconnecting");
      mqtt.disconnect();
      mqttWasConnected = false;
      mqttFailureStreak = 1;
      nextMqttReconnectAt = millis() + MQTT_RECONNECT_MIN_MS;
      return;
    }
    publishStatus(true);
    publishTelemetry();
  } else {
    mqttFailureStreak++;
    nextMqttReconnectAt = millis() + reconnectDelay(
        MQTT_RECONNECT_MIN_MS, MQTT_RECONNECT_MAX_MS, mqttFailureStreak);
    Serial.printf("MQTT failed, rc=%d, retry in %lums\n",
                  mqtt.state(), nextMqttReconnectAt - millis());
  }
}

void configureMqttServer() {
  IPAddress directAddress;
  if (directAddress.fromString(MQTT_HOST)) {
    mqtt.setServer(directAddress, MQTT_PORT);
    Serial.printf("MQTT direct endpoint: %s:%d\n", MQTT_HOST, MQTT_PORT);
    return;
  }
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  if (!WiFi.isConnected()) {
    Serial.println("MQTT broker hostname retained for DNS lookup after WiFi connects");
    return;
  }

  IPAddress resolvedBroker;
  if (WiFi.hostByName(MQTT_HOST, resolvedBroker)) {
    Serial.printf("MQTT broker resolved: %s\n", resolvedBroker.toString().c_str());
    return;
  }
  Serial.println("MQTT DNS lookup failed; retaining broker hostname for retry");
}

// ตรวจเวลาปิดอัตโนมัติ ป้องกันวาล์วหรือปั๊มเปิดค้าง
void enforceAutoOff() {
  unsigned long now = millis();
  RelayOutput *outputs[] = {&pumpWater, &pumpFertilizer, &zones[0], &zones[1], &zones[2], &zones[3]};
  for (auto *output : outputs) {
    if (output->enabled && output->autoOffAt > 0
        && static_cast<long>(now - output->autoOffAt) >= 0) {
      setRelay(*output, false);
      publishTelemetry();
    }
  }
  if (irrigationSource != IrrigationSource::None && !pumpWater.enabled && !anyZoneEnabled()) {
    if (irrigationSource == IrrigationSource::Auto && autoCycleStartedAt > 0) {
      autoDailyRuntimeSeconds += (now - autoCycleStartedAt) / 1000UL;
      lastAutoStopAt = now;
    }
    irrigationSource = IrrigationSource::None;
    autoCycleStartedAt = 0;
  }
}

// ตรวจระดับน้ำ/อัตราการไหล และสั่งหยุดเมื่อพบความผิดปกติ
void enforceSafetyProtections() {
  if (!pumpWater.enabled) {
    return;
  }

  if (irrigationSource == IrrigationSource::Auto && autoCycleStartedAt > 0) {
    uint32_t projectedSeconds = autoDailyRuntimeSeconds + (millis() - autoCycleStartedAt) / 1000UL;
    if (projectedSeconds >= autoDailyRuntimeLimitMinutes * 60UL) {
      allOutputsOff();
      publishAlarm("auto_daily_limit", "Daily automatic irrigation limit reached", "warning");
      publishTelemetry();
      return;
    }
  }

  if (autoWaterLevelProtection) {
    if (!hasNumber(waterLevel) && autoFailSafeOnSensorLoss) {
      allOutputsOff();
      publishAlarm("sensor_disconnected", "Water level sensor is unavailable", "critical");
      publishTelemetry();
      return;
    }
    if (hasNumber(waterLevel) && waterLevel < MIN_SAFE_WATER_LEVEL_PERCENT) {
      allOutputsOff();
      publishAlarm("water_level_low", "Water level is below the safe threshold", "critical");
      publishTelemetry();
      return;
    }
  }

  bool shouldCheckFlow = pumpWaterStartedAt > 0 && millis() - pumpWaterStartedAt >= FLOW_CHECK_DELAY_MS;
  if (shouldCheckFlow && (autoFlowProtection || autoDryRunProtection)) {
    if (!hasNumber(flowRate) && autoFailSafeOnSensorLoss) {
      allOutputsOff();
      publishAlarm("sensor_disconnected", "Flow sensor is unavailable after pump start", "critical");
      publishTelemetry();
      return;
    }
    if (hasNumber(flowRate) && flowRate < MIN_FLOW_RATE_LPM) {
      allOutputsOff();
      publishAlarm(autoDryRunProtection ? "pump_dry_run" : "no_flow", "No water flow detected after pump start", "critical");
      publishTelemetry();
    }
  }
}

// ตัดสินใจรดน้ำอัตโนมัติจากความชื้นดินและค่าที่ตั้งไว้
void runAutoMode() {
  if (!autoModeEnabled || millis() - lastAutoCheckAt < 10000UL) {
    return;
  }

  lastAutoCheckAt = millis();
  struct tm timeinfo;
  if (getLocalTime(&timeinfo, 10) && timeinfo.tm_yday != autoRuntimeDay) {
    autoRuntimeDay = timeinfo.tm_yday;
    autoDailyRuntimeSeconds = 0;
  }

  if (isnan(sensors.soilMoisture)) {
    if (autoFailSafeOnSensorLoss && irrigationSource == IrrigationSource::Auto) {
      allOutputsOff();
      publishAlarm("sensor_disconnected", "Soil moisture sensor was lost during auto irrigation", "critical");
      publishTelemetry();
    }
    return;
  }

  if (sensors.soilMoisture < autoMinMoisture && !pumpWater.enabled && !anyZoneEnabled()) {
    if (lastAutoStopAt > 0 && millis() - lastAutoStopAt < autoCooldownMinutes * 60UL * 1000UL) return;
    if (autoDailyRuntimeSeconds >= autoDailyRuntimeLimitMinutes * 60UL) {
      if (lastAutoLimitAlarmAt == 0 || millis() - lastAutoLimitAlarmAt > 300000UL) {
        lastAutoLimitAlarmAt = millis();
        publishAlarm("auto_daily_limit", "Daily automatic irrigation limit reached", "warning");
      }
      return;
    }
    for (uint8_t attempt = 0; attempt < 4; attempt++) {
      uint8_t zoneIndex = (nextAutoZone + attempt) % 4;
      if ((autoZoneMask & (1 << zoneIndex)) == 0) continue;
      nextAutoZone = (zoneIndex + 1) % 4;
      uint32_t remainingSeconds = autoDailyRuntimeLimitMinutes * 60UL - autoDailyRuntimeSeconds;
      uint32_t configuredSeconds = autoMaxRuntimeSeconds;
      uint32_t runSeconds = min(configuredSeconds, remainingSeconds);
      if (startWaterOutput(zones[zoneIndex], runSeconds, "auto mode")) {
        String message = String("Auto irrigation started on Zone ") + String(zoneIndex + 1);
        publishAlarm("auto_mode", message.c_str(), "info");
      }
      break;
    }
  }

  if (sensors.soilMoisture > autoMaxMoisture && irrigationSource == IrrigationSource::Auto) {
    allOutputsOff();
    publishAlarm("auto_mode", "Auto irrigation stopped by moisture threshold", "info");
  }
}

// ตรวจวันและเวลา แล้วเริ่มรายการรดน้ำที่ตรงกับตาราง
void runSchedules() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 10)) {
    return;
  }

  int currentMinute = timeinfo.tm_hour * 60 + timeinfo.tm_min;
  if (currentMinute == lastScheduleMinute) {
    return;
  }

  lastScheduleMinute = currentMinute;
  uint8_t dayMask = 1 << timeinfo.tm_wday;
  for (uint8_t i = 0; i < scheduleCount; i++) {
    ScheduleItem &item = schedules[i];
    if (!item.enabled || !(item.daysMask & dayMask) || item.zone < 1 || item.zone > 4) {
      continue;
    }

    if (item.startMinute == currentMinute) {
      if (startWaterOutput(zones[item.zone - 1], item.durationMinutes * 60UL, "schedule")) {
        publishAlarm("schedule_started", "Schedule irrigation started", "info");
        publishTelemetry();
      }
    }
  }
}

void setupTopics() {
  String base = String(MQTT_BASE_TOPIC) + "/" + DEVICE_ID;
  commandTopic = base + "/commands";
  telemetryTopic = base + "/telemetry";
  statusTopic = base + "/status";
  alarmTopic = base + "/alarms";
  ackTopic = base + "/ack";
}

// เริ่ม RS485 และกำหนด Slave ID ของรีเลย์ เซนเซอร์ และ HMI
void setupModbus() {
  RS485Serial.end();
  RS485Serial.begin(modbusBaudRate, SERIAL_8N1, RS485_RXD, RS485_TXD);
  RS485Serial.setTimeout(200);
  node1.begin(relayNodeId, RS485Serial);
  node2.begin(sensor3In1NodeId, RS485Serial);
  node3.begin(soil4In1NodeId, RS485Serial);
  node4.begin(npkNodeId, RS485Serial);
#if HMI_MODBUS_ENABLED
  nodeHmi.begin(HMI_NODE_ID, RS485Serial);
#endif
}

// setup() ทำงานครั้งเดียวเมื่อเปิดเครื่องหรือกด Reset
void setup() {
  Serial.begin(115200);
  delay(500);
  randomSeed(static_cast<uint32_t>(ESP.getEfuseMac()));
  Serial.println();
  Serial.println("Smart Farm Controller booting");
  lockOnboardRelaysOff();
  Serial.println("Onboard ESP relays locked OFF");
  setupLcd();
  preferences.begin("smartfarm", false);
  Serial.println("Preferences ready");
  loadRuntimeConfig();
  Serial.printf("Runtime WiFi SSID: %s\n", runtimeWifiSsid.c_str());
  setupTopics();
  Serial.println("MQTT topics ready");
  setupModbus();
  Serial.println("Modbus ready");
#if MODBUS_SCAN_ON_BOOT
  scanModbusBus();
#endif
#if RELAY_READ_ONLY_SCAN_ON_BOOT
  scanRelayReadOnly();
#endif
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);
#if !MQTT_ALLOW_PUBLIC_BROKER
  if (strlen(MQTT_ROOT_CA) > 0) {
    mqttNetworkClient.setCACert(MQTT_ROOT_CA);
  }
  mqttNetworkClient.setHandshakeTimeout(MQTT_SOCKET_TIMEOUT_SECONDS);
#endif
  mqttNetworkClient.setTimeout(MQTT_SOCKET_TIMEOUT_SECONDS);
  configureMqttServer();
  mqtt.setCallback(mqttCallback);
  mqtt.setBufferSize(1536);
  mqtt.setKeepAlive(MQTT_KEEPALIVE_SECONDS);
  mqtt.setSocketTimeout(MQTT_SOCKET_TIMEOUT_SECONDS);
  Serial.println("Network clients ready");
  connectWiFi();
  configTime(7 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  Serial.println("Turning outputs off");
  allOutputsOff();
  Serial.println("Setup completed");
}

// loop() วนซ้ำตลอดเวลา ไม่ควรใส่ delay ยาวเพราะระบบนิรภัยจะตอบสนองช้า
void loop() {
  lockOnboardRelaysOff();

  if (wifiReconnectRequested) {
    wifiReconnectRequested = false;
    mqtt.disconnect();
    mqttNetworkClient.stop();
    WiFi.disconnect(false, false);
    wifiAttemptInProgress = false;
    wifiWasConnected = false;
    mqttWasConnected = false;
    wifiFailureStreak = 0;
    mqttFailureStreak = 0;
    nextWifiReconnectAt = 0;
    nextMqttReconnectAt = 0;
  }

  connectWiFi();
  connectMqtt();
  mqtt.loop();
  pollSensorsRealtime();
  pollRelayFeedback();
  syncHmi();
  enforceAutoOff();
  enforceSafetyProtections();
  runSchedules();
  runAutoMode();
  updateLcd();

  if (mqtt.connected() && millis() - lastTelemetryAt >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryAt = millis();
    publishTelemetry();
  }
  yield();
}

#endif
