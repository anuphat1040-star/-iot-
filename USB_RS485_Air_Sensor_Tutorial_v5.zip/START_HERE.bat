@echo off
chcp 65001 >nul
cd /d "%~dp0"
title USB-RS485 Air Sensor Tutorial

where py.exe >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py.exe"

if not defined PYTHON_CMD (
  where python.exe >nul 2>nul
  if not errorlevel 1 set "PYTHON_CMD=python.exe"
)

if not defined PYTHON_CMD goto NO_PYTHON

%PYTHON_CMD% -c "import serial" >nul 2>nul
if errorlevel 1 goto INSTALL_SERIAL
goto RUN_PROGRAM

:INSTALL_SERIAL
echo Installing pyserial. Please wait about 1-2 minutes...
%PYTHON_CMD% -m pip install pyserial
if errorlevel 1 goto INSTALL_FAILED
goto RUN_PROGRAM

:RUN_PROGRAM
echo.
echo Starting USB-RS485 Air Sensor Tutorial...
echo.
%PYTHON_CMD% usb_rs485_air_sensor.py
goto FINISH

:NO_PYTHON
echo Python was not found.
echo Install Python 3 and enable "Add python.exe to PATH".
goto FINISH

:INSTALL_FAILED
echo.
echo pyserial installation failed. Check the internet connection.
goto FINISH

:FINISH
echo.
echo Press any key to close this window.
pause >nul
