"""
บทเรียนอ่านและเปลี่ยน ID เซนเซอร์อากาศ 3-in-1 ผ่าน USB-to-RS485

คำสั่ง:
  AUTO        ค้นหา COM, Baud และ ID 1-10
  PORTS       แสดงพอร์ต COM ทั้งหมด
  PORT COM11  เลือกพอร์ต
  BAUD 9600   เลือก Baud rate
  SCAN        ค้นหา ID 1-10
  SCANALL     ค้นหา ID 1-247
  READ 2      อ่านความชื้น อุณหภูมิ และแสงจาก ID 2
  PROBE 2     อ่าน Register ตั้งค่า ID/Baud โดยไม่เขียนค่า
  SET 2 6     เตรียมเปลี่ยน ID 2 เป็น 6
  SETBAUD 6 9600  เตรียมเปลี่ยน Baud ของ ID 6 เป็น 9600
  CONFIRM     ยืนยันการเขียน
  CANCEL      ยกเลิก
  EXIT        ปิดโปรแกรม

โปรโตคอล RS-GZWS-N01 อ่าน Register 0-2 ด้วย Function 03 และเปลี่ยน ID
โดยเขียน Register 0x07D0 ด้วย Function 06
"""

import sys
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    print("ยังไม่มีไลบรารี pyserial")
    print("ให้ดับเบิลคลิกไฟล์ install_pyserial.bat ก่อน")
    input("กด Enter เพื่อปิด...")
    raise SystemExit(1)


COMMON_BAUDS = (9600, 4800, 19200, 2400)
RESPONSE_TIMEOUT = 0.25
ID_REGISTER = 0x07D0
BAUD_REGISTER = 0x07D1


def crc16(data: bytes) -> int:
    """คำนวณ CRC-16 Modbus"""
    value = 0xFFFF
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0xA001 if value & 1 else 0)
    return value


def add_crc(payload: bytes) -> bytes:
    """เติม CRC แบบ Low byte ก่อน High byte"""
    value = crc16(payload)
    return payload + bytes((value & 0xFF, value >> 8))


def valid_crc(frame: bytes) -> bool:
    if len(frame) < 4:
        return False
    expected = int.from_bytes(frame[-2:], "little")
    return crc16(frame[:-2]) == expected


def available_ports():
    return list(list_ports.comports())


def print_ports():
    ports = available_ports()
    if not ports:
        print("ไม่พบพอร์ต COM: ตรวจ USB และไดรเวอร์")
        return []
    print("พอร์ต COM ที่พบ:")
    for item in ports:
        print(f"  {item.device}: {item.description}")
    return ports


class AirSensorTool:
    def __init__(self):
        self.port_name = None
        self.baud = 9600
        self.port = None
        self.pending = None

    def close(self):
        if self.port and self.port.is_open:
            self.port.close()
        self.port = None

    def open(self, port_name=None, baud=None):
        if port_name:
            self.port_name = port_name.upper()
        if baud:
            self.baud = baud
        if not self.port_name:
            return False

        self.close()
        try:
            self.port = serial.Serial(
                self.port_name,
                self.baud,
                bytesize=8,
                parity=serial.PARITY_NONE,
                stopbits=1,
                timeout=0.02,
                write_timeout=1.0,
            )
            self.port.dtr = False
            self.port.rts = False
            time.sleep(0.08)
            return True
        except serial.SerialException as error:
            print(f"เปิด {self.port_name} ไม่สำเร็จ: {error}")
            self.port = None
            return False

    def exchange(self, request: bytes) -> bytes:
        if not self.port or not self.port.is_open:
            return b""
        self.port.reset_input_buffer()
        self.port.write(request)
        self.port.flush()

        response = bytearray()
        started = time.monotonic()
        last_byte = started
        while time.monotonic() - started < RESPONSE_TIMEOUT:
            waiting = self.port.in_waiting
            if waiting:
                response.extend(self.port.read(waiting))
                last_byte = time.monotonic()
            if len(response) >= 5 and time.monotonic() - last_byte > 0.008:
                break
            time.sleep(0.001)
        return bytes(response)

    def read_registers(self, device_id: int, start_register: int, count: int):
        """อ่าน Holding Registers ด้วย Function 03"""
        request = add_crc(bytes((
            device_id, 0x03,
            (start_register >> 8) & 0xFF, start_register & 0xFF,
            (count >> 8) & 0xFF, count & 0xFF,
        )))
        response = self.exchange(request)
        expected_length = 5 + count * 2
        if len(response) != expected_length or not valid_crc(response):
            return None
        if response[0] != device_id or response[1] != 0x03 or response[2] != count * 2:
            return None
        return [
            int.from_bytes(response[3 + i * 2:5 + i * 2], "big")
            for i in range(count)
        ]

    def read_sensor(self, device_id: int):
        values = self.read_registers(device_id, 0x0000, 3)
        if values is None:
            return None
        humidity = values[0] / 10.0
        signed_temperature = values[1] if values[1] < 0x8000 else values[1] - 0x10000
        temperature = signed_temperature / 10.0
        lux = values[2]
        return humidity, temperature, lux

    def show_sensor(self, device_id: int):
        values = self.read_sensor(device_id)
        if values is None:
            print(f"อ่าน ID {device_id} ไม่ได้: ตรวจ Baud, D+/D-, ไฟเลี้ยง และ GND")
            return False
        humidity, temperature, lux = values
        print(f"อ่าน ID {device_id} สำเร็จ")
        print(f"  ความชื้นอากาศ = {humidity:.1f} %RH")
        print(f"  อุณหภูมิ      = {temperature:.1f} °C")
        print(f"  ความสว่าง      = {lux} lux")
        return True

    def probe_config(self, device_id: int):
        """อ่านค่าตั้งโดยไม่แก้ไข เพื่อยืนยันโปรโตคอลก่อน SET"""
        values = self.read_registers(device_id, ID_REGISTER, 2)
        if values is None:
            print(f"ID {device_id} ไม่ตอบ Register 0x07D0-0x07D1")
            print("อย่าใช้ SET จนกว่าจะตรวจรุ่นหรือคู่มือเพิ่มเติม")
            return False

        address_value, baud_code = values
        baud_names = {
            0: 2400, 1: 4800, 2: 9600, 3: 19200,
            4: 38400, 5: 57600, 6: 115200, 7: 1200,
        }
        print("อ่าน Register ตั้งค่าสำเร็จ (ยังไม่มีการเขียน)")
        print(f"  0x07D0 Device ID = {address_value}")
        print(f"  0x07D1 Baud code = {baud_code}", end="")
        if baud_code in baud_names:
            print(f" ({baud_names[baud_code]} baud)")
        else:
            print(" (ไม่รู้จักรหัสนี้)")
        return address_value == device_id

    def scan(self, first_id=1, last_id=10, quiet=False):
        if not self.port:
            print("ยังไม่ได้เลือกพอร์ต ใช้ PORT COM11 หรือ AUTO")
            return []
        if not quiet:
            print(f"ค้นหา {self.port_name}, {self.baud} baud, ID {first_id}-{last_id}")
        found = []
        for device_id in range(first_id, last_id + 1):
            if self.read_sensor(device_id) is not None:
                found.append(device_id)
                if not quiet:
                    print(f"  พบเซนเซอร์ที่ ID {device_id}")
            if not quiet and last_id > 20 and device_id % 20 == 0:
                print(f"  ตรวจถึง ID {device_id}")
        if not quiet:
            print(f"ค้นหาเสร็จ พบ {len(found)} ตัว")
        return found

    def auto_detect(self):
        ports = available_ports()
        if not ports:
            print("ไม่พบพอร์ต COM")
            return
        print("เริ่มค้นหา USB-RS485, Baud และ ID 1-10...")
        for item in ports:
            for baud in COMMON_BAUDS:
                print(f"ทดลอง {item.device}, {baud} baud")
                if not self.open(item.device, baud):
                    continue
                found = self.scan(1, 10, quiet=True)
                if found:
                    print(f"พบเซนเซอร์: PORT={item.device}, BAUD={baud}, ID={found}")
                    print("โปรแกรมเลือกค่านี้ให้แล้ว ใช้ READ ตามด้วย ID")
                    return
        print("ยังไม่พบเซนเซอร์: ตรวจไฟเลี้ยง, GND และลองสลับ D+ กับ D-")

    def prepare_change(self, old_id: int, new_id: int):
        if not (1 <= old_id <= 247 and 1 <= new_id <= 247):
            print("ID ต้องอยู่ระหว่าง 1-247")
            return
        if old_id == new_id:
            print("ID เดิมและใหม่เหมือนกัน")
            return
        if self.read_sensor(old_id) is None:
            print("ไม่พบเซนเซอร์ที่ ID เดิม จึงยกเลิก")
            return
        if self.read_sensor(new_id) is not None:
            print("ID ใหม่ถูกใช้อยู่แล้ว ห้ามตั้งซ้ำ")
            return
        if not self.probe_config(old_id):
            print("Register ตั้งค่าไม่ตรง จึงยกเลิกเพื่อความปลอดภัย")
            return
        self.pending = {
            "kind": "id",
            "device_id": old_id,
            "value": new_id,
            "expires": time.monotonic() + 30,
        }
        print(f"เตรียมเปลี่ยน ID {old_id} -> {new_id} แต่ยังไม่ได้เขียน")
        print("ต่อเซนเซอร์เพียงตัวเดียว แล้วพิมพ์ CONFIRM ภายใน 30 วินาที")

    def prepare_baud_change(self, device_id: int, new_baud: int):
        """ตรวจค่าปัจจุบันก่อนเตรียมเขียน Baud code ลง 0x07D1"""
        baud_to_code = {
            2400: 0, 4800: 1, 9600: 2, 19200: 3,
            38400: 4, 57600: 5, 115200: 6, 1200: 7,
        }
        if new_baud not in baud_to_code:
            print("รองรับ 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200")
            return
        if self.read_sensor(device_id) is None:
            print("อ่านเซนเซอร์ไม่ได้ ให้ใช้ AUTO หรือ BAUD เลือกความเร็วปัจจุบันก่อน")
            return

        config = self.read_registers(device_id, ID_REGISTER, 2)
        if config is None or config[0] != device_id:
            print("อ่าน Register ตั้งค่าไม่ได้ จึงยกเลิกเพื่อความปลอดภัย")
            return

        new_code = baud_to_code[new_baud]
        if config[1] == new_code:
            print(f"เซ็นเซอร์ถูกตั้งเป็น {new_baud} baud อยู่แล้ว")
            return

        self.pending = {
            "kind": "baud",
            "device_id": device_id,
            "value": new_code,
            "new_baud": new_baud,
            "expires": time.monotonic() + 30,
        }
        print(f"เตรียมเปลี่ยน Baud ของ ID {device_id}: {self.baud} -> {new_baud}")
        print(f"จะเขียนค่า {new_code} ลง Register 0x07D1 แต่ยังไม่ได้เขียน")
        print("ต่อเซนเซอร์เพียงตัวเดียว แล้วพิมพ์ CONFIRM ภายใน 30 วินาที")

    def write_single_register(self, device_id: int, register: int, value: int):
        """เขียนหนึ่ง Holding Register ด้วย Function 06 และตรวจเฟรม echo"""
        request = add_crc(bytes((
            device_id, 0x06,
            (register >> 8) & 0xFF, register & 0xFF,
            (value >> 8) & 0xFF, value & 0xFF,
        )))
        response = self.exchange(request)
        return response == request and valid_crc(response)

    def confirm_change(self):
        if not self.pending or time.monotonic() > self.pending["expires"]:
            self.pending = None
            print("ไม่มีรายการรอยืนยันหรือหมดเวลาแล้ว")
            return

        pending = self.pending
        self.pending = None

        if pending["kind"] == "id":
            old_id = pending["device_id"]
            new_id = pending["value"]
            print("กำลังเขียน ID ห้ามปิดไฟหรือถอดสาย...")
            confirmed = self.write_single_register(old_id, ID_REGISTER, new_id)
            if confirmed:
                print("เซนเซอร์ตอบยืนยันการเขียน Register 0x07D0 แล้ว")
            else:
                print("ไม่พบเฟรมยืนยัน ห้ามสั่ง SET ซ้ำทันที")
            print("ปิดไฟเซนเซอร์ 5 วินาที เปิดใหม่ แล้วใช้ SCAN และ READ IDใหม่")
            return

        device_id = pending["device_id"]
        baud_code = pending["value"]
        new_baud = pending["new_baud"]
        print("กำลังเขียน Baud rate ห้ามปิดไฟหรือถอดสาย...")
        confirmed = self.write_single_register(device_id, BAUD_REGISTER, baud_code)
        if confirmed:
            print("เซนเซอร์ตอบยืนยันการเขียน Register 0x07D1 แล้ว")
        else:
            print("ไม่พบเฟรมยืนยัน ห้ามสั่ง SETBAUD ซ้ำทันที")
        print("ปิดไฟเซนเซอร์ 5 วินาที เปิดใหม่ แล้วพิมพ์ AUTO เพื่อตรวจสอบ")


def parse_id(text):
    try:
        value = int(text)
        return value if 1 <= value <= 247 else None
    except ValueError:
        return None


def print_help():
    print("\n========== USB-RS485 Air Sensor ==========")
    print("PORTS       แสดงพอร์ต COM")
    print("PORT COM11  เลือกพอร์ต")
    print("AUTO        ค้นหา COM, Baud และ ID 1-10")
    print("BAUD 9600   เลือก Baud")
    print("SCAN        ค้นหา ID 1-10")
    print("SCANALL     ค้นหา ID 1-247")
    print("READ 2      อ่านเซนเซอร์ ID 2")
    print("PROBE 2     อ่าน Register ID/Baud โดยไม่เขียน")
    print("SET 2 6     เตรียมเปลี่ยน ID 2 เป็น 6")
    print("SETBAUD 6 9600  เตรียมเปลี่ยน Baud ของ ID 6")
    print("CONFIRM     ยืนยันการเปลี่ยน")
    print("CANCEL      ยกเลิก")
    print("EXIT        ปิดโปรแกรม")
    print("==========================================\n")


def main():
    tool = AirSensorTool()
    print("บทเรียนเซนเซอร์อากาศผ่าน USB-to-RS485")
    print_ports()
    print_help()

    try:
        while True:
            command = input("RS485> ").strip().upper()
            if not command:
                continue
            parts = command.split()

            if command == "HELP":
                print_help()
            elif command == "PORTS":
                print_ports()
            elif len(parts) == 2 and parts[0] == "PORT":
                if tool.open(parts[1], tool.baud):
                    print(f"เลือก {tool.port_name} ที่ {tool.baud} baud แล้ว")
            elif command == "AUTO":
                tool.auto_detect()
            elif len(parts) == 2 and parts[0] == "BAUD":
                try:
                    baud = int(parts[1])
                except ValueError:
                    baud = 0
                if baud not in (1200, 2400, 4800, 9600, 19200, 38400):
                    print("รองรับ 1200, 2400, 4800, 9600, 19200, 38400")
                elif tool.open(tool.port_name, baud):
                    print(f"เปลี่ยนเป็น {baud} baud แล้ว")
                else:
                    print("เลือก PORT ก่อน")
            elif command == "SCAN":
                tool.scan(1, 10)
            elif command == "SCANALL":
                tool.scan(1, 247)
            elif len(parts) == 2 and parts[0] == "READ":
                device_id = parse_id(parts[1])
                if device_id:
                    tool.show_sensor(device_id)
                else:
                    print("ตัวอย่าง: READ 2")
            elif len(parts) == 2 and parts[0] == "PROBE":
                device_id = parse_id(parts[1])
                if device_id:
                    tool.probe_config(device_id)
                else:
                    print("ตัวอย่าง: PROBE 2")
            elif len(parts) == 3 and parts[0] == "SET":
                old_id, new_id = parse_id(parts[1]), parse_id(parts[2])
                if old_id and new_id:
                    tool.prepare_change(old_id, new_id)
                else:
                    print("ตัวอย่าง: SET 2 6")
            elif len(parts) == 3 and parts[0] == "SETBAUD":
                device_id = parse_id(parts[1])
                try:
                    new_baud = int(parts[2])
                except ValueError:
                    new_baud = 0
                if device_id:
                    tool.prepare_baud_change(device_id, new_baud)
                else:
                    print("ตัวอย่าง: SETBAUD 6 9600")
            elif command == "CONFIRM":
                tool.confirm_change()
            elif command == "CANCEL":
                tool.pending = None
                print("ยกเลิกแล้ว ไม่มีการเขียนค่า")
            elif command in ("EXIT", "QUIT"):
                break
            else:
                print("ไม่รู้จักคำสั่ง พิมพ์ HELP")
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        tool.close()
        print("ปิดโปรแกรมแล้ว")


if __name__ == "__main__":
    main()

