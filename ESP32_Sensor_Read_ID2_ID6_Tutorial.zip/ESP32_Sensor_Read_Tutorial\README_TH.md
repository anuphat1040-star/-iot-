# บทเรียน ESP32 อ่านเซนเซอร์ผ่าน Serial Monitor

ตัวอย่างนี้ใช้ ESP32-S3 อ่านเซนเซอร์สองตัวบน RS485/Modbus บัสเดียวกัน แล้วแสดงผลใน Serial Monitor:

- เซนเซอร์ดิน 7-in-1 ใช้ ID 2
- เซนเซอร์อากาศ 3-in-1 ใช้ ID 6

## ก่อนอัปโหลด

เปิดไฟล์ `ESP32_Sensor_Read_Tutorial.ino` แล้วตรวจค่าด้านบนของโค้ด:

```cpp
const uint8_t RS485_TX_PIN = 17;
const uint8_t RS485_RX_PIN = 18;
const uint32_t MODBUS_BAUD = 9600;
const uint8_t SOIL_SENSOR_ID = 2;
const uint8_t AIR_SENSOR_ID = 6;
```

- แก้ TX/RX เมื่อใช้ขาอื่น
- Baud rate ต้องตรงกับเซนเซอร์
- ID ของเซนเซอร์ทั้งสองต้องตรงกับอุปกรณ์จริงและห้ามซ้ำกัน
- เซนเซอร์ทั้งสองต้องใช้ 9600 baud, 8N1 เหมือนกัน

## ไลบรารี

ติดตั้ง `ModbusMaster` รุ่น 2.0.1 ผ่าน Library Manager

## ตั้งค่า Arduino IDE

```text
Board: ESP32S3 Dev Module
USB CDC On Boot: Enabled
Upload Speed: 921600 หรือ 115200
Serial Monitor: 115200 baud
```

## การต่อสาย

```text
ESP32 GPIO17 (TX) -> RX/DI ของโมดูล RS485
ESP32 GPIO18 (RX) <- TX/RO ของโมดูล RS485
ESP32 GND         -> GND ของโมดูล RS485
RS485 A           -> A ของเซนเซอร์
RS485 B           -> B ของเซนเซอร์
```

โมดูล RS485 ต้องรองรับลอจิก 3.3V ห้ามนำสาย A/B ต่อเข้าขา ESP32 โดยตรง

## วิธีทดลอง

1. ต่อวงจรโดยยังไม่ต่อปั๊มหรือรีเลย์
2. เปิดไฟล์ `.ino` ด้วย Arduino IDE
3. กด Verify
4. เลือก COM ของ ESP32 แล้วกด Upload
5. เปิด Serial Monitor ที่ 115200 baud
6. โปรแกรมจะอ่านเซนเซอร์ดิน ID 2 แล้วอ่านเซนเซอร์อากาศ ID 6 ทุก 2 วินาที

ค่าที่แสดงประกอบด้วย:

- ดิน: ความชื้น อุณหภูมิ EC, pH, N, P, K และความเค็ม
- อากาศ: ความชื้น อุณหภูมิ และความสว่าง

## ถ้าอ่านไม่ได้

- ตรวจไฟเลี้ยงเซนเซอร์และ GND ร่วม
- ลองสลับสาย A กับ B
- ตรวจว่า Baud rate เป็น 9600
- ตรวจว่าเซนเซอร์ดินเป็น ID 2 และเซนเซอร์อากาศเป็น ID 6
- ตรวจคู่มือเซนเซอร์ว่าใช้ Function Code 03 และ Register เริ่มต้น 0 จริงหรือไม่

